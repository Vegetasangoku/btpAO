'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  ShieldCheck,
  Activity,
  Building2,
  CreditCard,
  Gauge,
  Server,
  HardHat,
  LogOut,
  ChevronRight,
  Sparkles,
  KeyRound,
  Layers,
  Cpu,
  Globe,
  Sun,
  Moon,
  Laptop,
  Clock,
} from 'lucide-react';
import { supabase } from '@/lib/supabase/client';
import { useTheme } from '@/components/theme-provider';
import { useTranslation, Language } from '@/components/i18n-provider';

export function SuperAdminSidebar() {
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();
  const { language, setLanguage, t } = useTranslation();

  async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = '/login';
  }

  const superAdminNav = [
    { name: t('layout.admin_sidebar.nav_dashboard'), href: '/admin', icon: Activity, badge: t('layout.admin_sidebar.badge_direct') },
    { name: t('layout.admin_sidebar.nav_tenants'), href: '/admin/tenants', icon: Building2, badge: '69' },
    { name: t('layout.admin_sidebar.nav_billing'), href: '/admin/billing', icon: CreditCard },
    { name: t('layout.admin_sidebar.nav_cost_limits'), href: '/admin/costs', icon: Gauge },
    { name: t('layout.admin_sidebar.nav_infra'), href: '/admin/infrastructure', icon: Server },
    { name: t('layout.admin_sidebar.nav_whitelist'), href: '/admin/whitelist', icon: Globe },
  ];

  return (
    <aside className="w-64 bg-white dark:bg-[#111A24] border-r border-slate-200/80 dark:border-[#243546] flex flex-col h-screen sticky top-0 z-30 select-none transition-colors duration-150">
      {/* Brand Super Admin */}
      <div className="p-4 border-b border-slate-200/80 dark:border-[#243546]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#1C6091] text-white flex items-center justify-center shadow-xs font-bold shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="font-heading font-extrabold text-sm text-slate-900 dark:text-white tracking-tight flex items-center gap-1.5">
              <span>btp</span><span className="text-[#1C6091]">AO</span>
              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-[#1C6091]/10 text-[#1C6091] border border-[#1C6091]/20">
                {t('layout.admin_sidebar.badge_admin')}
              </span>
            </div>
            <p className="text-[9px] text-slate-400 dark:text-zinc-400 font-mono truncate">charbelakl@gmail.com</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        <div>
          <p className="eyebrow-mono !text-slate-400 dark:!text-zinc-500 px-2.5 mb-1">
            {t('layout.admin_sidebar.section_platform')}
          </p>
          <nav className="space-y-0.5">
            {superAdminNav.map((item) => {
              const isActive = pathname === item.href;
              const Icon = item.icon;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  prefetch={false}
                  className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-all ${
                    isActive
                      ? 'bg-[#1C6091] text-white font-semibold shadow-xs'
                      : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#16212D] font-medium'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? 'text-white' : 'text-slate-400 dark:text-zinc-500'}`} />
                    <span className="truncate">{item.name}</span>
                  </div>
                  {isActive && <ChevronRight className="w-3 h-3 text-white/80 shrink-0" />}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Operational View Banner */}
        <div className="relative p-3 mx-1 card-drafted !bg-slate-50 dark:!bg-[#16212D] space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5 font-heading">
              <HardHat className="w-3.5 h-3.5 text-[#1C6091]" />
              <span>{t('layout.admin_sidebar.operational_space')}</span>
            </p>
            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-[#1C6091]/15 text-[#1C6091]">
              BTP
            </span>
          </div>
          <p className="text-[10px] text-slate-500 dark:text-zinc-400 leading-tight">
            {t('layout.admin_sidebar.operational_desc')}
          </p>
          <Link
            href="/dashboard"
            prefetch={false}
            className="flex items-center justify-center gap-1.5 w-full py-2 px-3 rounded-lg bg-[#1C6091] hover:bg-[#154A73] text-white text-xs font-semibold transition-colors shadow-xs"
          >
            <span>{t('layout.admin_sidebar.open_btp_space')}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* Footer: Language + Theme + Logout */}
      <div className="p-3 border-t border-slate-200/80 dark:border-zinc-800/80 bg-white dark:bg-[#090B0F] space-y-2">
        {/* Quick Language Switcher (FR / EN / AR) */}
        <div className="flex items-center justify-between px-2 py-1 rounded-lg bg-slate-50 dark:bg-zinc-900/60 border border-slate-200/80 dark:border-zinc-800/80 text-[10px]">
          <div className="flex items-center gap-1.5 text-slate-500 dark:text-zinc-400 font-mono font-semibold pl-1">
            <Globe className="w-3 h-3 text-zinc-400" />
            <span>{t('app.language')}</span>
          </div>
          <div className="flex gap-0.5 bg-slate-200/60 dark:bg-zinc-800/60 p-0.5 rounded-md">
            {(['fr', 'en', 'ar'] as Language[]).map((l) => (
              <button
                key={l}
                type="button"
                onClick={() => setLanguage(l)}
                title={l.toUpperCase()}
                className={`px-1.5 py-0.5 rounded text-[9px] font-bold font-mono transition-all cursor-pointer ${
                  language === l
                    ? 'bg-[#1C6091] text-white font-bold shadow-xs'
                    : 'text-slate-500 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {l.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Theme Switcher */}
        <div className="flex items-center justify-between px-2 py-1 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] text-[10px]">
          <span className="text-muted-foreground font-mono font-semibold pl-1">{t('app.theme')}</span>
          <div className="flex gap-0.5 bg-slate-200/60 dark:bg-[#111A24] p-0.5 rounded-md">
            <button
              type="button"
              onClick={() => setTheme('light')}
              title="Mode Clair"
              className={`p-1 rounded transition-all cursor-pointer ${
                theme === 'light'
                  ? 'bg-[#1C6091] text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200'
              }`}
            >
              <Sun className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => setTheme('dark')}
              title="Mode Sombre"
              className={`p-1 rounded transition-all cursor-pointer ${
                theme === 'dark'
                  ? 'bg-[#1C6091] text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200'
              }`}
            >
              <Moon className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => setTheme('schedule')}
              title="Horaires Chantier"
              className={`p-1 rounded transition-all cursor-pointer ${
                theme === 'schedule'
                  ? 'bg-[#1C6091] text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setTheme('system')}
              title="Système (OS)"
              className={`p-1 rounded transition-all cursor-pointer ${
                theme === 'system'
                  ? 'bg-[#1C6091] text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200'
              }`}
            >
              <Laptop className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold text-slate-500 dark:text-zinc-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>{t('layout.admin_sidebar.logout')}</span>
        </button>
      </div>
    </aside>
  );
}
