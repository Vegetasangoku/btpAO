'use client';

/**
 * Page d'accueil.
 *
 * Direction : le dossier de candidature et le chantier, pas l'informatique. Une
 * photographie de viaduc en construction tient toute la moitié droite de l'ouverture ;
 * en face, une composition typographique sobre. L'élément signature est la bande de
 * jalons : la réponse à un appel d'offres est une course contre une date de remise, et
 * cette frise dit en une ligne où la plateforme intervient dans cette course.
 *
 * Vocabulaire : aucun terme technique d'implémentation. On parle de pièces du marché,
 * d'exigences, de mémoire technique — les mots des personnes qui font ce travail.
 */

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useTranslation, Language } from '@/components/i18n-provider';

const INK = '#0E1A24';
const PAPER = '#F7F6F4';
const CORTEN = '#B5651D';
const MUTED = '#5A6270';
const RULE = 'rgba(14,26,36,0.12)';

/** Bande de jalons — l'élément signature.
 *
 *  Une réponse à appel d'offres est une course contre une date de remise : la frise dit
 *  en une ligne où la plateforme intervient dans cette course. Les jalons couverts
 *  portent un repère plein ; les deux extrêmes, qui restent le fait de l'acheteur, un
 *  repère effacé. Dessinée comme une réglette : un filet, des repères qui descendent,
 *  les libellés dessous.
 */
function MilestoneStrip({ labels, coveredFrom, coveredTo }: { labels: string[]; coveredFrom: number; coveredTo: number }) {
  return (
    <div className="w-full">
      <div className="h-px w-full" style={{ background: RULE }} />
      <div className="grid" style={{ gridTemplateColumns: `repeat(${labels.length}, minmax(0, 1fr))` }}>
        {labels.map((label, i) => {
          const covered = i >= coveredFrom && i <= coveredTo;
          return (
            <div key={label} className="flex flex-col">
              {/* Hauteur de repère constante : seule la longueur du trait varie, pour que
                  tous les libellés partagent la même ligne de base. */}
              <span className="block w-px h-3">
                <span
                  className="block w-px"
                  style={{ height: covered ? 12 : 6, background: covered ? CORTEN : RULE }}
                />
              </span>
              <span
                className="block font-mono text-[9px] uppercase leading-[1.5] tracking-[0.08em] pe-2 pt-1.5"
                style={{ color: covered ? INK : MUTED, minHeight: 34 }}
              >
                {label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function LandingPage() {
  const { t, language, setLanguage, isRtl } = useTranslation();
  const [openQuestion, setOpenQuestion] = useState<number | null>(0);

  const stages = [
    { key: 'pieces', label: t('home.stage.pieces_label') },
    { key: 'exigences', label: t('home.stage.requirements_label') },
    { key: 'decision', label: t('home.stage.decision_label') },
    { key: 'memoire', label: t('home.stage.memo_label') },
  ];

  const milestones = [
    t('home.milestone.published'),
    t('home.milestone.analysis'),
    t('home.milestone.decision'),
    t('home.milestone.drafting'),
    t('home.milestone.submitted'),
  ];

  const questions = [0, 1, 2, 3, 4].map((i) => ({
    q: t(`home.faq.q${i + 1}`),
    a: t(`home.faq.a${i + 1}`),
  }));

  return (
    <div dir={isRtl ? 'rtl' : 'ltr'} style={{ background: PAPER, color: INK }} className="min-h-screen">
      {/* ── En-tête ──────────────────────────────────────────────────────── */}
      {/* Barre opaque : un fond translucide laissait les titres défiler visiblement
          derrière, ce qui brouillait la lecture au défilement. */}
      <header className="sticky top-0 z-40" style={{ background: PAPER, borderBottom: `1px solid ${RULE}` }}>
        <div className="mx-auto max-w-[1240px] px-6 lg:px-10 h-14 flex items-center justify-between gap-6">
          <Link href="/" className="font-heading font-black text-[17px] tracking-tight">
            btp<span style={{ color: CORTEN }}>AO</span>
          </Link>

          <nav className="hidden md:flex items-center gap-7 text-[12.5px]" style={{ color: MUTED }}>
            <a href="#plateforme" className="hover:text-[#0E1A24] transition-colors duration-100">{t('home.nav.platform')}</a>
            <a href="#garanties" className="hover:text-[#0E1A24] transition-colors duration-100">{t('home.nav.guarantees')}</a>
            <a href="#tarifs" className="hover:text-[#0E1A24] transition-colors duration-100">{t('home.nav.pricing')}</a>
            <a href="#questions" className="hover:text-[#0E1A24] transition-colors duration-100">{t('home.nav.questions')}</a>
          </nav>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-0.5 font-mono text-[10px]">
              {(['fr', 'en', 'ar'] as Language[]).map((l) => (
                <button
                  key={l}
                  onClick={() => setLanguage(l)}
                  className="px-1.5 py-1 rounded-[3px] uppercase font-semibold transition-colors duration-100"
                  style={
                    language === l
                      ? { background: INK, color: PAPER }
                      : { color: MUTED }
                  }
                >
                  {l === 'ar' ? 'ع' : l}
                </button>
              ))}
            </div>
            <Link href="/login" className="text-[12.5px] font-medium hover:opacity-70 transition-opacity duration-100">
              {t('home.cta.sign_in')}
            </Link>
            <Link
              href="/register"
              className="px-3.5 py-1.5 rounded-[4px] text-[12.5px] font-semibold text-white transition-colors duration-150"
              style={{ background: INK }}
            >
              {t('home.cta.create_account')}
            </Link>
          </div>
        </div>
      </header>

      {/* ── Ouverture ────────────────────────────────────────────────────── */}
      <section className="grid lg:grid-cols-[minmax(0,54%)_minmax(0,46%)]">
        <div className="px-6 lg:px-10 xl:ps-[max(2.5rem,calc((100vw-1240px)/2+2.5rem))] py-14 lg:py-24 flex flex-col justify-center">
          <p className="font-mono text-[10px] uppercase tracking-[0.24em]" style={{ color: CORTEN }}>
            {t('home.brand.sector')}
          </p>

          <h1
            className="mt-6 font-heading font-bold"
            style={{ fontSize: 'clamp(38px, 5.2vw, 64px)', lineHeight: 1.02, letterSpacing: '-0.032em' }}
          >
            {t('home.hero.title_line1')}
            <br />
            <span style={{ color: MUTED }}>{t('home.hero.title_line2')}</span>
          </h1>

          <p className="mt-6 max-w-[46ch] text-[15px] leading-[1.65]" style={{ color: MUTED }}>
            {t('home.hero.body')}
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-5">
            <Link
              href="/register"
              className="px-5 py-2.5 rounded-[4px] text-[13.5px] font-semibold text-white transition-colors duration-150 hover:bg-[#1C6091]"
              style={{ background: INK }}
            >
              {t('home.cta.create_account')}
            </Link>
            <Link href="/login" className="text-[13.5px] font-medium underline underline-offset-4 decoration-1 hover:opacity-70 transition-opacity duration-100">
              {t('home.cta.sign_in')}
            </Link>
          </div>

          {/* Élément signature */}
          <div className="mt-14 max-w-xl">
            <MilestoneStrip labels={milestones} coveredFrom={1} coveredTo={3} />
            <p className="mt-4 text-[11.5px]" style={{ color: MUTED }}>
              {t('home.milestone.legend')}
            </p>
          </div>
        </div>

        <div className="relative min-h-[380px] lg:min-h-[calc(100vh-3.5rem)]" style={{ borderInlineStart: `1px solid ${RULE}` }}>
          <Image
            src="/images/login-hero.jpg"
            alt={t('home.photo.alt')}
            fill
            priority
            sizes="(max-width: 1024px) 100vw, 46vw"
            className="object-cover"
          />
          <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#0A1319]/80 to-transparent" />
          <p className="absolute bottom-5 start-6 end-6 font-mono text-[9.5px] uppercase tracking-[0.18em] text-white/75">
            {t('home.photo.caption_kicker')}
          </p>
        </div>
      </section>

      {/* ── La plateforme ────────────────────────────────────────────────── */}
      <section id="plateforme" className="mx-auto max-w-[1240px] px-6 lg:px-10 py-20 lg:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-[10px] uppercase tracking-[0.24em]" style={{ color: CORTEN }}>
            {t('home.nav.platform')}
          </p>
          <h2 className="mt-4 font-heading font-bold" style={{ fontSize: 'clamp(26px, 3vw, 38px)', lineHeight: 1.1, letterSpacing: '-0.025em' }}>
            {t('home.platform.heading')}
          </h2>
        </div>

        <div className="mt-12" style={{ borderTop: `1px solid ${RULE}` }}>
          {stages.map((stage, i) => (
            <div
              key={stage.key}
              className="grid md:grid-cols-[140px_minmax(0,1fr)_minmax(0,1.1fr)] gap-x-8 gap-y-2 py-7"
              style={{ borderBottom: `1px solid ${RULE}` }}
            >
              <span className="font-mono text-[10px] uppercase tracking-[0.16em] pt-1" style={{ color: CORTEN }}>
                {stage.label}
              </span>
              <h3 className="font-heading text-[19px] font-semibold tracking-tight">
                {t(`home.platform.${stage.key}_title`)}
              </h3>
              <p className="text-[13.5px] leading-[1.7]" style={{ color: MUTED }}>
                {t(`home.platform.${stage.key}_body`)}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Ce qui reste à vous ──────────────────────────────────────────── */}
      <section id="garanties" style={{ background: INK, color: PAPER }}>
        <div className="mx-auto max-w-[1240px] px-6 lg:px-10 py-20 lg:py-24">
          <h2
            className="font-heading font-bold max-w-2xl"
            style={{ fontSize: 'clamp(24px, 2.6vw, 34px)', lineHeight: 1.12, letterSpacing: '-0.022em', color: PAPER }}
          >
            {t('home.guarantees.heading')}
          </h2>
          <div className="mt-12 grid md:grid-cols-3 gap-px" style={{ background: 'rgba(247,246,244,0.14)' }}>
            {['references', 'templates', 'data'].map((k) => (
              <div key={k} className="p-7" style={{ background: INK }}>
                <h3 className="font-heading text-[16px] font-semibold" style={{ color: PAPER }}>
                  {t(`home.guarantees.${k}_title`)}
                </h3>
                <p className="mt-2.5 text-[13.5px] leading-[1.7]" style={{ color: 'rgba(247,246,244,0.66)' }}>
                  {t(`home.guarantees.${k}_body`)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Tarifs ───────────────────────────────────────────────────────── */}
      <section id="tarifs" className="mx-auto max-w-[1240px] px-6 lg:px-10 py-20 lg:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-[10px] uppercase tracking-[0.24em]" style={{ color: CORTEN }}>
            {t('home.nav.pricing')}
          </p>
          <h2 className="mt-4 font-heading font-bold" style={{ fontSize: 'clamp(26px, 3vw, 38px)', lineHeight: 1.1, letterSpacing: '-0.025em' }}>
            {t('home.pricing.heading')}
          </h2>
        </div>

        <div className="mt-12 overflow-x-auto">
          <table className="w-full min-w-[640px] border-collapse text-[13.5px]">
            <thead>
              <tr style={{ borderBottom: `1px solid ${INK}` }}>
                <th className="text-start pb-4 pe-6 font-mono text-[10px] uppercase tracking-[0.16em] font-medium" style={{ color: MUTED }}>
                  {t('home.pricing.col_label')}
                </th>
                {(['starter', 'pro', 'enterprise'] as const).map((p) => (
                  <th key={p} className="text-start pb-4 pe-6 align-bottom">
                    <span className="block font-heading text-[17px] font-semibold tracking-tight">
                      {t(`home.plan.${p}_name`)}
                    </span>
                    <span className="block text-[12px] mt-0.5" style={{ color: MUTED }}>
                      {t(`home.plan.${p}_note`)}
                    </span>
                    {p === 'pro' && (
                      <span className="inline-block mt-2 font-mono text-[9.5px] uppercase tracking-[0.16em]" style={{ color: CORTEN }}>
                        {t('home.pricing.recommended')}
                      </span>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { k: 'price', values: ['199 €', '499 €', t('home.plan.on_quote')], mono: true },
                { k: 'dossiers', values: ['3', '10', t('home.pricing.custom_volume')], mono: true },
                { k: 'extra', values: ['99 €', '79 €', t('home.pricing.negotiated')], mono: true },
                { k: 'library', values: [t('home.pricing.library_starter'), t('home.pricing.library_pro'), t('home.pricing.library_enterprise')] },
                { k: 'support', values: [t('home.pricing.support_starter'), t('home.pricing.support_pro'), t('home.pricing.support_enterprise')] },
              ].map((row) => (
                <tr key={row.k} style={{ borderBottom: `1px solid ${RULE}` }}>
                  <th className="text-start py-3.5 pe-6 font-normal align-top" style={{ color: MUTED }}>
                    {t(`home.pricing.row_${row.k}`)}
                  </th>
                  {row.values.map((v, i) => (
                    <td key={i} className={`py-3.5 pe-6 align-top ${row.mono ? 'font-mono tabular-nums' : ''}`}>
                      {v}
                    </td>
                  ))}
                </tr>
              ))}
              <tr>
                <td />
                {(['starter', 'pro', 'enterprise'] as const).map((p) => (
                  <td key={p} className="pt-5 pe-6">
                    <Link
                      href={`/register?plan=${p}`}
                      className="inline-block px-4 py-2 rounded-[4px] text-[12.5px] font-semibold transition-colors duration-150"
                      style={
                        p === 'pro'
                          ? { background: INK, color: '#fff' }
                          : { border: `1px solid ${RULE}`, color: INK }
                      }
                    >
                      {t('home.pricing.choose')}
                    </Link>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
        <p className="mt-5 text-[12px]" style={{ color: MUTED }}>
          {t('home.pricing.footnote')}
        </p>
      </section>

      {/* ── Questions ────────────────────────────────────────────────────── */}
      <section id="questions" className="mx-auto max-w-[1240px] px-6 lg:px-10 pb-24">
        <h2 className="font-heading font-bold" style={{ fontSize: 'clamp(24px, 2.6vw, 32px)', letterSpacing: '-0.022em' }}>
          {t('home.faq.heading')}
        </h2>
        <div className="mt-10 max-w-3xl" style={{ borderTop: `1px solid ${RULE}` }}>
          {questions.map((item, i) => (
            <div key={i} style={{ borderBottom: `1px solid ${RULE}` }}>
              <button
                type="button"
                onClick={() => setOpenQuestion(openQuestion === i ? null : i)}
                aria-expanded={openQuestion === i}
                className="w-full flex items-baseline justify-between gap-6 py-5 text-start"
              >
                <span className="text-[15px] font-medium">{item.q}</span>
                <span className="font-mono text-[13px] shrink-0" style={{ color: MUTED }}>
                  {openQuestion === i ? '−' : '+'}
                </span>
              </button>
              {openQuestion === i && (
                <p className="pb-6 pe-10 text-[13.5px] leading-[1.75] max-w-[62ch]" style={{ color: MUTED }}>
                  {item.a}
                </p>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* ── Pied de page ─────────────────────────────────────────────────── */}
      <footer style={{ borderTop: `1px solid ${RULE}` }}>
        <div className="mx-auto max-w-[1240px] px-6 lg:px-10 py-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
          <div>
            <p className="font-heading font-black text-[15px] tracking-tight">
              btp<span style={{ color: CORTEN }}>AO</span>
            </p>
            <p className="mt-1 text-[12px]" style={{ color: MUTED }}>
              {t('home.footer.line')}
            </p>
          </div>
          <div className="flex items-center gap-6 text-[12px]" style={{ color: MUTED }}>
            <Link href="/login" className="hover:text-[#0E1A24] transition-colors duration-100">{t('home.cta.sign_in')}</Link>
            <Link href="/register" className="hover:text-[#0E1A24] transition-colors duration-100">{t('home.cta.create_account')}</Link>
            <a href="#tarifs" className="hover:text-[#0E1A24] transition-colors duration-100">{t('home.nav.pricing')}</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
