import React from 'react';
import { SuperAdminSidebar } from '@/components/layout/super-admin-sidebar';

export default function SuperAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen bg-[#EAF1F5] dark:bg-[#0A121A] text-slate-800 dark:text-zinc-100 transition-colors duration-150 font-sans">
      <SuperAdminSidebar />
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <div className="flex-1 p-5 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
