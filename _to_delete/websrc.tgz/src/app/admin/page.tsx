'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import {
  ShieldAlert,
  Building2,
  Cpu,
  Sliders,
  DollarSign,
  TrendingUp,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Server,
  Zap,
  Layers,
  Save,
  Users,
  Search,
  Settings2,
  Plus,
  Trash2,
  Loader2,
  Mail,
  ChevronRight,
  Key,
  Database,
  FileCode,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { supabase } from '@/lib/supabase/client';
import { api } from '@/lib/api';
import { LLM_MODEL_TIERS } from '@/lib/types';
import type { LlmCatalogResponse } from '@/lib/types';
import { useTranslation } from '@/components/i18n-provider';
import { DismissibleNotice } from '@/components/ui/dismissible-notice';


interface Tenant {
  id: string;
  name: string;
  slug?: string;
  plan: string;
  country_code?: string;
  siret?: string;
  contact_email?: string;
  monthly_limit?: number;
  used_this_month?: number;
  llm_provider?: string;
  llm_model?: string;
  llm_model_tier?: string;
  model_routing_config?: {
    extraction_gonogo?: { provider: string; model: string };
    redaction_memoire?: { provider: string; model: string };
    analyse_prix?: { provider: string; model: string };
  };
}


function SuperAdminPageContent() {
  const { t } = useTranslation();
  const searchParams = useSearchParams();
  const [activeTab, setActiveTab] = useState<'tenants' | 'master_keys' | 'routing' | 'rag_supervision' | 'prompts' | 'revenue'>('master_keys');
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [loading, setLoading] = useState(true);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Permet à d'autres pages (ex: /admin/tenants) de lier directement vers le
  // formulaire de création plutôt que de simplement renvoyer sur /admin.
  useEffect(() => {
    if (searchParams?.get('create') === '1') {
      setShowCreateModal(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  // 01/09 : permet à la page de détail tenant de lier directement vers un onglet
  // précis (ex: /admin?tab=routing depuis le renvoi ajouté sur l'onglet de routage
  // dupliqué de /admin/tenants/[id]) plutôt que de toujours retomber sur master_keys.
  useEffect(() => {
    const tabParam = searchParams?.get('tab');
    const validTabs = ['tenants', 'master_keys', 'routing', 'rag_supervision', 'prompts', 'revenue'];
    if (tabParam && validTabs.includes(tabParam)) {
      setActiveTab(tabParam as typeof activeTab);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);
  const [isCreating, setIsCreating] = useState(false);
  const [notice, setNotice] = useState<{ message: string; detail?: string; variant?: 'error' | 'success' } | null>(null);
  const [llmCatalog, setLlmCatalog] = useState<LlmCatalogResponse | null>(null);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [catalogSyncing, setCatalogSyncing] = useState(false);

  // Master LLM Keys & Platform Default Model State
  const [platformDefaultTier, setPlatformDefaultTier] = useState('equilibre');
  // Sélection en attente du sélecteur "appliquer aux 3 tâches" du routage par tâche,
  // par tenant -- state local, rien n'est envoyé tant que l'admin ne clique pas sur
  // le bouton d'application (30/08, réponse à "je dois me faire chier trois fois ?").
  const [bulkRoutingSelection, setBulkRoutingSelection] = useState<Record<string, string>>({});
  const [customProviders, setCustomProviders] = useState<any[]>([
    { id: 'anthropic', name: 'Anthropic Claude — rédaction des mémoires techniques', litellm_id: 'anthropic/claude-sonnet-5', api_key: '', api_base: '', zone: 'US', enabled: true },
    { id: 'openai', name: 'OpenAI — lecture des plans et raisonnement sur la DPGF', litellm_id: 'openai/gpt-5.6-terra', api_key: '', api_base: '', zone: 'US', enabled: true },
    { id: 'mistral', name: 'Mistral AI — hébergement européen, marchés publics', litellm_id: 'mistral/mistral-large-3-25-12', api_key: '', api_base: '', zone: 'UE', enabled: true },
    { id: 'gemini', name: 'Google Gemini — palier gratuit pour les essais', litellm_id: 'gemini/gemini-3.8-flash', api_key: '', api_base: '', zone: 'US', enabled: true },
    { id: 'deepseek', name: 'DeepSeek — coût plancher, hors UE', litellm_id: 'deepseek/deepseek-v4-flash', api_key: '', api_base: 'https://api.deepseek.com/v1', zone: 'Chine', enabled: true },
  ]);
  // 30/08 : surcharge de modele par palier (model_tier_overrides) -- le backend supportait deja
  // ce champ (voir admin.py::update_llm_keys) mais aucune UI ne l'exposait encore. availableTiers
  // vient de GET /admin/llm-keys::available_tiers (tiers avec surcharge deja appliquee, pour
  // afficher le modele reellement actif par palier, pas seulement le defaut code en dur).
  const [tierOverrides, setTierOverrides] = useState<Record<string, string>>({});
  const [availableTiers, setAvailableTiers] = useState<Record<string, any>>({});
  const [keyStatus, setKeyStatus] = useState<any>(null);
  // 30/08 : suivi de consommation LLM (tokens + cout estime par fournisseur, ce mois-ci) --
  // reponse a une demande explicite utilisateur, voir GET /admin/llm-usage-summary.
  const [usageSummary, setUsageSummary] = useState<any>(null);
  const [usageLoading, setUsageLoading] = useState(false);
  // 30/08 : remplace le calcul frontend MRR/ARR (grille de prix codee en dur et fausse,
  // multipliee par TOUS les tenants y compris demo/essai) par le vrai calcul serveur --
  // voir GET /admin/revenue-summary.
  const [revenueSummary, setRevenueSummary] = useState<any>(null);
  const [revenueLoading, setRevenueLoading] = useState(false);
  const [isSavingKeys, setIsSavingKeys] = useState(false);
  const [testingProviderId, setTestingProviderId] = useState<string | null>(null);

  // RAG Supervision State
  const [ragStats, setRagStats] = useState<any>({
    embedding_model: 'text-embedding-3-small',
    dimensions: 1536,
    similarity_metric: 'Cosinus (1 - (a <=> b))',
    total_dce_chunks: 0,
    total_knowledge_chunks: 0,
    index_type: 'HNSW',
  });


  // System Prompt Editor State
  const [selectedTenantForPrompt, setSelectedTenantForPrompt] = useState<string>('');
  const [currentPrompt, setCurrentPrompt] = useState<string>('');
  const [isSavingPrompt, setIsSavingPrompt] = useState(false);

  // Tab 2 search filter state
  const [routingSearch, setRoutingSearch] = useState<string>('');

  // New tenant form state
  const [newTenantName, setNewTenantName] = useState('');
  const [newTenantSiret, setNewTenantSiret] = useState('');
  const [newTenantEmail, setNewTenantEmail] = useState('');
  const [newTenantPlan, setNewTenantPlan] = useState('pro');
  const [newTenantModelTier, setNewTenantModelTier] = useState('inherit');
  const [newTenantModel, setNewTenantModel] = useState('anthropic/claude-sonnet-5');


  // Repli hors ligne : ce que l'écran affiche tant que le catalogue synchronisé n'a pas
  // répondu. Miroir du socle serveur app/services/llm_reference_catalog.py, relevé le
  // 2026-09-02 sur les pages tarifaires officielles. Tarifs en dollars par million de
  // tokens (entrée / sortie).
  const BUILTIN_MODEL_CHOICES: Record<string, Array<{ id: string; label: string; cost: string }>> = {
    anthropic: [
      { id: 'anthropic/claude-sonnet-5', label: 'Claude Sonnet 5 (rédaction du mémoire technique)', cost: '2.00 $ / 10.00 $ par M tokens' },
      { id: 'anthropic/claude-haiku-4-5-20251001', label: 'Claude Haiku 4.5 (extraction rapide du DCE)', cost: '1.00 $ / 5.00 $ par M tokens' },
      { id: 'anthropic/claude-opus-5', label: 'Claude Opus 5 (analyse juridique)', cost: '5.00 $ / 25.00 $ par M tokens' },
      { id: 'anthropic/claude-fable-5-1', label: 'Claude Fable 5.1 (dossiers à fort enjeu)', cost: '10.00 $ / 50.00 $ par M tokens' },
    ],
    openai: [
      { id: 'openai/gpt-5.6-terra', label: 'GPT-5.6 Terra (usage courant)', cost: '1.00 $ / 6.00 $ par M tokens' },
      { id: 'openai/gpt-5.6-sol', label: 'GPT-5.6 Sol (raisonnement approfondi)', cost: '2.00 $ / 10.00 $ par M tokens' },
      { id: 'openai/gpt-5.6-luna', label: 'GPT-5.6 Luna (traitement de masse)', cost: '0.10 $ / 0.60 $ par M tokens' },
      { id: 'openai/gpt-5.3-codex', label: 'GPT-5.3 Codex (structuration de données)', cost: '1.75 $ / 14.00 $ par M tokens' },
    ],
    mistral: [
      { id: 'mistral/mistral-large-3-25-12', label: 'Mistral Large 3 (souveraineté UE, marchés publics)', cost: '0.50 $ / 1.50 $ par M tokens' },
      { id: 'mistral/mistral-medium-3.5-26.04', label: 'Mistral Medium 3.5', cost: '1.50 $ / 7.50 $ par M tokens' },
      { id: 'mistral/mistral-small-4-0-26-03', label: 'Mistral Small 4 (économique, UE)', cost: '0.15 $ / 0.60 $ par M tokens' },
      { id: 'mistral/leanstral-1.5', label: 'Leanstral 1.5 — gratuit (Labs, UE)', cost: 'gratuit dans les quotas Mistral Labs' },
    ],
    gemini: [
      { id: 'gemini/gemini-3.8-flash', label: 'Gemini 3.8 Flash — palier gratuit (recette)', cost: 'gratuit dans les quotas Google AI Studio, puis 0.75 $ / 3.75 $' },
      { id: 'gemini/gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash-Lite', cost: 'gratuit dans les quotas, puis 0.30 $ / 2.50 $' },
      { id: 'gemini/gemini-2.5-pro', label: 'Gemini 2.5 Pro', cost: 'gratuit dans les quotas, puis 1.25 $ / 10.00 $' },
    ],
    deepseek: [
      { id: 'deepseek/deepseek-v4-flash', label: 'DeepSeek V4 Flash (coût plancher, hors UE)', cost: '0.44 $ / 1.32 $ par M tokens (heures pleines)' },
      { id: 'deepseek/deepseek-v4-pro', label: 'DeepSeek V4 Pro (hors UE)', cost: '1.32 $ / 3.96 $ par M tokens (heures pleines)' },
    ],
  };

  // Modèles par fournisseur dynamiquement synchronisés depuis le catalogue en base (mis à jour chaque nuit ou à la demande)
  const providerModelChoices = useMemo(() => {
    const choices: Record<string, Array<{ id: string; label: string; cost: string; isActive?: boolean }>> = {
      anthropic: [],
      openai: [],
      mistral: [],
      gemini: [],
      deepseek: [],
    };

    // 1. Ingestion des modèles issus du catalogue synchronisé (OpenRouter / APIs directes)
    if (llmCatalog?.models && llmCatalog.models.length > 0) {
      for (const m of llmCatalog.models) {
        const pSlug = (m.provider_slug || '').toLowerCase();
        let targetKey: string | null = null;
        if (pSlug.includes('anthropic')) targetKey = 'anthropic';
        else if (pSlug.includes('openai')) targetKey = 'openai';
        else if (pSlug.includes('mistral')) targetKey = 'mistral';
        else if (pSlug.includes('gemini') || pSlug.includes('google')) targetKey = 'gemini';
        else if (pSlug.includes('deepseek')) targetKey = 'deepseek';

        if (targetKey) {
          const costStr = (m.pricing_prompt_per_million != null && m.pricing_completion_per_million != null)
            ? `${m.pricing_prompt_per_million.toFixed(2)} $ / ${m.pricing_completion_per_million.toFixed(2)} $ par M tokens`
            : 'Tarif officiel fournisseur';

          choices[targetKey].push({
            id: m.external_id,
            label: `${m.display_name || m.external_id}${!m.is_active ? ' [Déprécié]' : ''}`,
            cost: costStr,
            isActive: m.is_active,
          });
        }
      }
    }

    // 2. Fusion avec les modèles phares prédéfinis pour garantir la présence au sommet des meilleurs modèles BTP
    for (const [provId, presets] of Object.entries(BUILTIN_MODEL_CHOICES)) {
      if (choices[provId].length === 0) {
        choices[provId] = presets.map((p) => ({ ...p, isActive: true }));
      } else {
        const existingIds = new Set(choices[provId].map((c) => c.id));
        for (const preset of presets) {
          if (!existingIds.has(preset.id)) {
            choices[provId].unshift({ ...preset, isActive: true });
          }
        }
      }
    }

    return choices;
  }, [llmCatalog]);

  // Rendu unifié de tous les modèles sélectionnables (intégrés + synchronisés du catalogue + personnalisés)
  function renderSelectableModelOptions() {
    const customList = customProviders.filter(
      (p) => !['anthropic', 'openai', 'mistral', 'deepseek'].includes(p.id) && (p.litellm_id || p.name)
    );

    return (
      <>
        <optgroup label="Anthropic Claude (Rédaction Mémoires Techniques & Analyse CCTP)">
          {(providerModelChoices.anthropic || []).map((m) => (
            <option key={m.id} value={m.id}>
              {m.label} ({m.cost})
            </option>
          ))}
        </optgroup>
        <optgroup label="OpenAI (Vision Plans, Raisonnement DPGF & Recherche Sémantique)">
          {(providerModelChoices.openai || []).map((m) => (
            <option key={m.id} value={m.id}>
              {m.label} ({m.cost})
            </option>
          ))}
        </optgroup>
        <optgroup label="Mistral AI (Souveraineté Européenne 🇪🇺 & Marchés Publics)">
          {(providerModelChoices.mistral || []).map((m) => (
            <option key={m.id} value={m.id}>
              {m.label} ({m.cost})
            </option>
          ))}
        </optgroup>
        <optgroup label="DeepSeek (Raisonnement Mathématique & Coût Plancher)">
          {(providerModelChoices.deepseek || []).map((m) => (
            <option key={m.id} value={m.id}>
              {m.label} ({m.cost})
            </option>
          ))}
        </optgroup>
        {customList.length > 0 && (
          <optgroup label="Modèles Personnalisés & Serveurs Privés">
            {customList.map((p) => (
              <option key={p.id} value={p.litellm_id || p.id}>
                {p.name || p.id} ({p.litellm_id || 'custom'}) {p.zone ? `[Zone ${p.zone}]` : ''}
              </option>
            ))}
          </optgroup>
        )}
      </>
    );
  }

  // Calcul en direct des détails du Modèle Master sélectionné pour feedback immédiat
  const activeMasterDetails = useMemo(() => {
    // 1. Profil / Tier prédéfini
    const tierMatch = LLM_MODEL_TIERS.find((t) => t.id === platformDefaultTier);
    if (tierMatch) {
      const rawModel = availableTiers[platformDefaultTier]?.model_string || tierOverrides[platformDefaultTier] || (
        platformDefaultTier === 'equilibre' ? 'anthropic/claude-sonnet-5' :
        platformDefaultTier === 'economique' ? 'anthropic/claude-haiku-4-5-20251001' :
        platformDefaultTier === 'avance' ? 'anthropic/claude-opus-5' :
        platformDefaultTier === 'souverain' ? 'mistral/mistral-large-3-25-12' :
        platformDefaultTier === 'gratuit' ? 'gemini/gemini-3.8-flash' :
        'anthropic/claude-fable-5-1'
      );
      const providerId = rawModel.split('/')[0];
      const provObj = customProviders.find((p) => p.id === providerId || (providerId === 'openai' && p.id === 'openai'));
      const hasKey = !!(
        (provObj?.api_key && provObj.api_key.trim() !== '') ||
        keyStatus?.custom_providers?.find((p: any) => p.id === providerId)?.api_key ||
        (providerId === 'anthropic' && keyStatus?.anthropic_api_key_configured) ||
        (providerId === 'openai' && keyStatus?.openai_api_key_configured) ||
        (providerId === 'mistral' && keyStatus?.mistral_api_key_configured)
      );
      return {
        isTier: true,
        tierName: tierMatch.name,
        modelString: rawModel,
        providerName: provObj?.name || providerId,
        providerId,
        zone: provObj?.zone || (providerId === 'mistral' ? 'UE' : 'US'),
        hasKey,
        pricing: tierMatch.pricing,
      };
    }

    // 2. Modèle direct sélectionné parmi les fournisseurs ou le catalogue
    const provObj = customProviders.find(
      (p) => p.litellm_id === platformDefaultTier || p.id === platformDefaultTier || (providerModelChoices[p.id]?.some((m) => m.id === platformDefaultTier))
    );
    const providerId = provObj?.id || platformDefaultTier.split('/')[0];
    const hasKey = !!(
      (provObj?.api_key && provObj.api_key.trim() !== '') ||
      keyStatus?.custom_providers?.find((p: any) => p.id === providerId)?.api_key ||
      (providerId === 'anthropic' && keyStatus?.anthropic_api_key_configured) ||
      (providerId === 'openai' && keyStatus?.openai_api_key_configured) ||
      (providerId === 'mistral' && keyStatus?.mistral_api_key_configured)
    );

    let cost = null;
    let label = platformDefaultTier;
    if (providerModelChoices[providerId]) {
      const mMatch = providerModelChoices[providerId].find((m) => m.id === platformDefaultTier);
      if (mMatch) {
        cost = mMatch.cost;
        label = mMatch.label;
      }
    }

    return {
      isTier: false,
      tierName: null,
      modelString: platformDefaultTier,
      label,
      providerName: provObj?.name || providerId,
      providerId,
      zone: provObj?.zone || (providerId === 'mistral' ? 'UE' : 'US'),
      hasKey,
      pricing: cost,
    };
  }, [platformDefaultTier, customProviders, keyStatus, availableTiers, tierOverrides]);


  useEffect(() => {
    fetchTenants();
    fetchMasterKeys();
    fetchRagStats();
    fetchLlmCatalog();
    fetchUsageSummary();
    fetchRevenueSummary();
  }, []);

  useEffect(() => {
    if (selectedTenantForPrompt) {
      fetchTenantPrompt(selectedTenantForPrompt);
    }
  }, [selectedTenantForPrompt]);

  async function fetchTenants() {
    setLoading(true);
    try {
      const data = await api.getTenants();
      const list = data || [];
      setTenants(list);
      if (list.length > 0 && !selectedTenantForPrompt) {
        setSelectedTenantForPrompt(list[0].id);
      }
    } catch (err: any) {
      console.error('Erreur chargement tenants:', err);
      setNotice({ message: t('admin.super.err_load_tenants'), detail: err?.message || String(err), variant: 'error' });
    } finally {
      setLoading(false);
    }
  }


  async function fetchMasterKeys() {
    try {
      const data = await api.getPlatformLLMKeys();
      if (data) {
        setKeyStatus(data);
        setTierOverrides(data.model_tier_overrides || {});
        setAvailableTiers(data.available_tiers || {});
        if (data.default_llm_tier) {
          setPlatformDefaultTier(data.default_llm_tier);
        }
        if (data.custom_providers && data.custom_providers.length > 0) {
          const standardNames: Record<string, string> = {
            anthropic: 'Anthropic Claude — rédaction des mémoires techniques',
            openai: 'OpenAI — lecture des plans et raisonnement sur la DPGF',
            mistral: 'Mistral AI — hébergement européen, marchés publics',
            gemini: 'Google Gemini — palier gratuit pour les essais',
            deepseek: 'DeepSeek — coût plancher, hors UE',
          };

          // Normalize legacy IDs to standard built-in IDs if present
          const normalized = data.custom_providers.map((p: any) => {
            let pid = p.id;
            if (pid === 'anthropic-claude' || pid === 'anthropic_claude') pid = 'anthropic';
            else if (pid === 'openai-custom' || pid === 'openai_custom') pid = 'openai';
            else if (pid === 'mistral-eu' || pid === 'mistral_eu') pid = 'mistral';
            else if (pid === 'google' || pid === 'google-gemini' || pid === 'google_gemini') pid = 'gemini';
            else if (pid === 'deepseek-custom' || pid === 'deepseek_custom') pid = 'deepseek';

            const name = standardNames[pid] || p.name;
            return { ...p, id: pid, name };
          });

          // Guarantee all 4 primary built-ins (anthropic, openai, mistral, deepseek) are present
          const existingIds = new Set(normalized.map((p: any) => p.id));
          const baseDefaults = [
            { id: 'anthropic', name: standardNames.anthropic, litellm_id: 'anthropic/claude-sonnet-5', api_key: '', api_base: '', zone: 'US', enabled: true },
            { id: 'openai', name: standardNames.openai, litellm_id: 'openai/gpt-5.6-terra', api_key: '', api_base: '', zone: 'US', enabled: true },
            { id: 'mistral', name: standardNames.mistral, litellm_id: 'mistral/mistral-large-3-25-12', api_key: '', api_base: '', zone: 'UE', enabled: true },
            { id: 'gemini', name: standardNames.gemini, litellm_id: 'gemini/gemini-3.8-flash', api_key: '', api_base: '', zone: 'US', enabled: true },
            { id: 'deepseek', name: standardNames.deepseek, litellm_id: 'deepseek/deepseek-v4-flash', api_key: '', api_base: 'https://api.deepseek.com/v1', zone: 'Chine', enabled: true },
          ];

          const merged = [...normalized];
          for (const base of baseDefaults) {
            if (!existingIds.has(base.id)) {
              merged.push(base);
            }
          }
          setCustomProviders(merged);
        }
      }
    } catch (e) {
      console.warn('[Admin] Fetch master keys notice:', e);
    }
  }

  // 29/08 : catalogue de modèles en lecture seule (référence OpenRouter -- voir i18n catalog_desc)
  async function fetchLlmCatalog() {
    setCatalogLoading(true);
    try {
      const data = await api.getLlmCatalog();
      setLlmCatalog(data);
    } catch (e) {
      console.warn('[Admin] Fetch LLM catalog notice:', e);
    } finally {
      setCatalogLoading(false);
    }
  }

  async function handleSyncLlmCatalog() {
    setCatalogSyncing(true);
    try {
      const result = await api.syncLlmCatalog();
      setNotice({
        message: t('admin.super.keys.catalog_sync_success', {
          created: String(result.created),
          updated: String(result.updated),
          deactivated: String(result.deactivated),
        }),
        variant: 'success',
      });
      await fetchLlmCatalog();
    } catch (e: any) {
      setNotice({ message: t('admin.super.keys.catalog_sync_error'), detail: e?.message || String(e), variant: 'error' });
    } finally {
      setCatalogSyncing(false);
    }
  }

  async function fetchUsageSummary() {
    setUsageLoading(true);
    try {
      const data = await api.getLlmUsageSummary();
      setUsageSummary(data);
    } catch (e) {
      console.warn('[Admin] Fetch usage summary notice:', e);
    } finally {
      setUsageLoading(false);
    }
  }

  async function fetchRevenueSummary() {
    setRevenueLoading(true);
    try {
      const data = await api.getRevenueSummary();
      setRevenueSummary(data);
    } catch (e) {
      console.warn('[Admin] Fetch revenue summary notice:', e);
    } finally {
      setRevenueLoading(false);
    }
  }

  async function fetchRagStats() {
    try {
      const data = await api.getRagSupervision();
      setRagStats(data);
    } catch (e) {
      console.warn('[Admin] Fetch RAG stats notice:', e);
    }
  }

  async function fetchTenantPrompt(tenantId: string) {
    try {
      const data = await api.getTenantSystemPrompt(tenantId);
      setCurrentPrompt(data.system_prompt || '');
    } catch (e) {
      console.warn('[Admin] Fetch system prompt notice:', e);
    }
  }

  function handleAddProvider() {
    const newId = `custom-provider-${Date.now()}`;
    setCustomProviders([
      ...customProviders,
      {
        id: newId,
        name: 'Nouveau Fournisseur',
        litellm_id: 'openai/custom-model',
        api_key: '',
        api_base: '',
        zone: 'autre',
        enabled: true,
      }
    ]);
  }

  function handleUpdateProvider(index: number, field: string, value: any) {
    const updated = [...customProviders];
    updated[index] = { ...updated[index], [field]: value };
    setCustomProviders(updated);
  }

  function handleDeleteProvider(index: number) {
    if (customProviders.length <= 1) {
      setNotice({ message: t('admin.super.err_min_provider'), variant: 'error' });
      return;
    }
    const updated = customProviders.filter((_, i) => i !== index);
    setCustomProviders(updated);
  }

  async function handleTestProvider(index: number) {
    const prov = customProviders[index];
    if (!prov) return;
    setTestingProviderId(prov.id);
    try {
      const res = await api.testLLMProvider({
        provider_id: prov.id,
        name: prov.name,
        litellm_id: prov.litellm_id,
        api_key: prov.api_key || undefined,
        api_base: prov.api_base || undefined,
      });
      const updated = [...customProviders];
      updated[index] = {
        ...updated[index],
        test_status: res.status,
        last_tested_at: res.tested_at,
        last_latency_ms: res.latency_ms,
        confirmed_model: (res as any).confirmed_model || prov.litellm_id,
        last_error_message: res.error_message || null,
      };
      setCustomProviders(updated);
    } catch (err: any) {
      const updated = [...customProviders];
      updated[index] = {
        ...updated[index],
        test_status: 'error',
        last_tested_at: new Date().toISOString(),
        last_error_message: err.message,
      };
      setCustomProviders(updated);
    } finally {
      setTestingProviderId(null);
    }
  }


  async function handleSaveMasterKeys(e: React.FormEvent) {
    e.preventDefault();
    setIsSavingKeys(true);
    try {
      await api.updatePlatformLLMKeys({
        default_llm_tier: platformDefaultTier,
        custom_providers: customProviders,
        model_tier_overrides: tierOverrides,
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
      fetchMasterKeys();
    } catch (err: any) {
      setNotice({ message: t('admin.super.err_save_keys'), detail: err.message, variant: 'error' });
    } finally {
      setIsSavingKeys(false);
    }
  }



  async function handleSaveSystemPrompt() {
    if (!selectedTenantForPrompt) return;
    setIsSavingPrompt(true);
    try {
      await api.updateTenantSystemPrompt(selectedTenantForPrompt, currentPrompt);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err: any) {
      setNotice({ message: t('admin.super.err_save_prompt'), detail: err.message, variant: 'error' });
    } finally {
      setIsSavingPrompt(false);
    }
  }

  const isDuplicateName = !!newTenantName.trim() && tenants.some(
    (t) => t.name.trim().toLowerCase() === newTenantName.trim().toLowerCase()
  );
  const isDuplicateSiret = !!newTenantSiret.trim() && tenants.some(
    (t) => t.siret && t.siret.trim() === newTenantSiret.trim()
  );

  async function handleCreateTenant(e: React.FormEvent) {
    e.preventDefault();
    if (!newTenantName.trim()) return;

    if (isDuplicateName) {
      setNotice({ message: t('admin.super.err_duplicate_name'), variant: 'error' });
      return;
    }

    if (isDuplicateSiret) {
      setNotice({ message: t('admin.super.err_duplicate_siret'), variant: 'error' });
      return;
    }

    setIsCreating(true);

    try {
      const slug = newTenantName.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-' + Math.floor(Math.random() * 1000);
      const created = await api.createTenant({
        name: newTenantName.trim(),
        slug,
        siret: newTenantSiret.trim() || undefined,
        contact_email: newTenantEmail.trim() || undefined,
        plan: newTenantPlan,
        country_code: 'FR',
        llm_model_tier: newTenantModelTier,
        llm_provider: 'anthropic',
        llm_model: newTenantModelTier !== 'inherit' ? newTenantModelTier : undefined,
      });

      if (created) {
        setTenants(prev => [created, ...prev]);
        setShowCreateModal(false);
        setNewTenantName('');
        setNewTenantSiret('');
        setNewTenantEmail('');
        setNewTenantModelTier('inherit');
        setNotice({ message: "Entreprise cliente créée avec succès.", variant: 'success' });
        setTimeout(() => setNotice(null), 3000);
      }
    } catch (err: any) {
      setNotice({ message: err.message || t('admin.super.err_create_tenant'), variant: 'error' });
    } finally {
      setIsCreating(false);
    }
  }


  async function handleUpdateModelRouting(tenantId: string, task: 'extraction_gonogo' | 'redaction_memoire' | 'analyse_prix', modelId: string) {
    const tenant = tenants.find(t => t.id === tenantId);
    if (!tenant) return;

    const provider = customProviders.find((p) => p.litellm_id === modelId)?.name
      || (modelId.includes('claude') ? 'Anthropic' : modelId.includes('gpt') ? 'OpenAI' : modelId.includes('mistral') ? 'Mistral AI' : 'Fournisseur');
    const updatedRouting = {
      ...(tenant.model_routing_config || {}),
      [task]: { provider, model: modelId },
    };

    setTenants(prev => prev.map(t => t.id === tenantId ? { ...t, model_routing_config: updatedRouting } : t));

    try {
      await api.updateTenantModelRouting({
        tenant_id: tenantId,
        [task]: { provider, model: modelId },
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err) {
      console.error('Erreur mise à jour routage:', err);
    }
  }

  // Applique le même modèle aux 3 tâches en un seul appel réseau (30/08, réponse directe à
  // "pourquoi je peux pas mettre un LLM pour les trois... je dois me faire chier trois
  // fois ?"). Réutilise le même endpoint POST /admin/model-routing que les 3 sélecteurs
  // individuels -- juste les 3 clés envoyées d'un coup au lieu d'un appel par tâche.
  async function handleBulkApplyModelRouting(tenantId: string, modelId: string) {
    const tenant = tenants.find(t => t.id === tenantId);
    if (!tenant || !modelId) return;

    const provider = customProviders.find((p) => p.litellm_id === modelId)?.name || 'Fournisseur';
    const entry = { provider, model: modelId };
    const updatedRouting = { extraction_gonogo: entry, redaction_memoire: entry, analyse_prix: entry };

    setTenants(prev => prev.map(t => t.id === tenantId ? { ...t, model_routing_config: updatedRouting } : t));

    try {
      await api.updateTenantModelRouting({ tenant_id: tenantId, ...updatedRouting });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err) {
      console.error('Erreur mise à jour routage (application groupée):', err);
    }
  }

  async function handleDeleteTenant(tenantId: string) {
    if (!confirm(t('admin.super.confirm_delete_tenant'))) return;
    const { error } = await supabase.from('tenants').delete().eq('id', tenantId);
    if (error) {
      setNotice({ message: t('admin.super.err_delete_tenant'), detail: error.message, variant: 'error' });
    } else {
      setTenants(prev => prev.filter(t => t.id !== tenantId));
    }
  }

  const filteredRoutingTenants = tenants.filter((tenant) => {
    if (!routingSearch.trim()) return true;
    const q = routingSearch.toLowerCase();
    return (
      tenant.name.toLowerCase().includes(q) ||
      (tenant.id && tenant.id.toLowerCase().includes(q)) ||
      (tenant.siret && tenant.siret.toLowerCase().includes(q)) ||
      (tenant.contact_email && tenant.contact_email.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 pb-16 max-w-6xl mx-auto">
      {/* ─── TAILGRIDS SUPER ADMIN KPI STATS CARDS ─── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Active LLM Providers */}
        <div className="bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-[#1C6091]/10 text-[#1C6091] flex items-center justify-center font-bold">
              <Cpu className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Providers</span>
          </div>
          <div>
            <span className="text-2xl font-black font-heading text-foreground">
              {customProviders.filter(p => p.enabled).length} <span className="text-xs text-muted-foreground font-normal">/ {customProviders.length}</span>
            </span>
            <p className="text-[11px] text-muted-foreground mt-0.5">Fournisseurs d'IA actifs</p>
          </div>
          <div className="w-full bg-slate-100 dark:bg-[#16212D] rounded-full h-1.5 overflow-hidden">
            <div className="bg-[#1C6091] h-1.5 rounded-full" style={{ width: `${Math.min(100, (customProviders.filter(p => p.enabled).length / Math.max(1, customProviders.length)) * 100)}%` }} />
          </div>
        </div>

        {/* Card 2: Entreprises Clientes */}
        <div className="bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Tenants</span>
          </div>
          <div>
            <span className="text-2xl font-black font-heading text-foreground">{tenants.length}</span>
            <p className="text-[11px] text-muted-foreground mt-0.5">Entreprises BTP enregistrées</p>
          </div>
          <div className="w-full bg-slate-100 dark:bg-[#16212D] rounded-full h-1.5 overflow-hidden">
            <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${Math.min(100, (tenants.length / 20) * 100)}%` }} />
          </div>
        </div>

        {/* Card 3: Consommation LLM */}
        <div className="bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <DollarSign className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Consommation</span>
          </div>
          <div>
            <span className="text-2xl font-black font-heading text-foreground">
              {usageSummary?.estimated_cost_usd != null ? `$${usageSummary.estimated_cost_usd.toFixed(2)}` : '$0.00'}
            </span>
            <p className="text-[11px] text-muted-foreground mt-0.5">Coût d'inférence ce mois-ci</p>
          </div>
          <div className="w-full bg-slate-100 dark:bg-[#16212D] rounded-full h-1.5 overflow-hidden">
            <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: '35%' }} />
          </div>
        </div>

        {/* Card 4: Chunks Vectoriels RAG */}
        <div className="bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Database className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Index RAG</span>
          </div>
          <div>
            <span className="text-2xl font-black font-heading text-foreground">
              {(ragStats.total_knowledge_chunks || 0) + (ragStats.total_dce_chunks || 0)}
            </span>
            <p className="text-[11px] text-muted-foreground mt-0.5">Vecteurs dce & savoir-faire</p>
          </div>
          <div className="w-full bg-slate-100 dark:bg-[#16212D] rounded-full h-1.5 overflow-hidden">
            <div className="bg-indigo-500 h-1.5 rounded-full" style={{ width: '60%' }} />
          </div>
        </div>
      </div>

      {/* Header with Title & Action */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#1C6091]/10 text-[#1C6091] border border-[#1C6091]/20">
              {t('admin.super.badge')}
            </span>
            <span className="text-xs text-muted-foreground font-mono">{t('admin.super.master_control')}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-foreground font-heading tracking-tight">
            {t('admin.super.heading')}
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {t('admin.super.subtitle')}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {saveSuccess && (
            <div className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-1.5 animate-fade-in-up">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{t('admin.super.save_success')}</span>
            </div>
          )}

          <button
            onClick={() => setShowCreateModal(true)}
            className="btn-primary !py-2 !px-3.5 !text-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t('admin.super.btn_create_tenant')}</span>
          </button>
        </div>
      </div>

      {notice && (
        <DismissibleNotice
          message={notice.message}
          detail={notice.detail}
          variant={notice.variant}
          onDismiss={() => setNotice(null)}
        />
      )}

      {/* Onglets de navigation segmentés */}
      <div className="p-1 rounded-xl bg-slate-100 dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] flex flex-wrap gap-1">
        {[
          { id: 'master_keys', label: t('admin.super.tab1'), icon: Key },
          { id: 'routing', label: t('admin.super.tab2'), icon: Cpu },
          { id: 'rag_supervision', label: t('admin.super.tab3'), icon: Database },
          { id: 'prompts', label: t('admin.super.tab4'), icon: FileCode },
          { id: 'tenants', label: t('admin.super.tab5'), icon: Building2 },
          { id: 'revenue', label: t('admin.super.tab6'), icon: DollarSign },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-white dark:bg-[#16212D] text-[#1C6091] dark:text-white font-bold shadow-xs border border-slate-200/80 dark:border-[#243546]'
                  : 'text-muted-foreground hover:text-foreground font-medium'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#1C6091]' : ''}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: MASTER LLM KEYS & CUSTOM PROVIDERS */}
      {activeTab === 'master_keys' && (
        <div className="space-y-6">
          {/* Guide Pédagogique d'Architecture LLM & Rôles BTP */}
          <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-[#243546] pb-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2 font-heading">
                <Sparkles className="w-4 h-4 text-[#1C6091]" />
                <span>Rôles des Modèles d'IA & Maîtrise des Coûts en Réponse aux Appels d'Offres</span>
              </h3>
              <span className="badge-pill font-medium">
                Dernière génération 2024-2025
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm">✍️</span>
                  <h4 className="font-bold text-slate-900 dark:text-white">Rédaction Mémoire</h4>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  <strong>Claude 3.5 Sonnet</strong> ou <strong>Mistral Large 2</strong> : rédaction technique soignée, phasage chantier, argumentaires QSE/RSE conformes au CCTP.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm">👁️</span>
                  <h4 className="font-bold text-slate-900 dark:text-white">Vision Plans & DCE</h4>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  <strong>OpenAI GPT-4o</strong> : compréhension visuelle des plans d'architecte, coupes, schémas de principe et pièces graphiques du dossier de consultation.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm">🔢</span>
                  <h4 className="font-bold text-slate-900 dark:text-white">Chiffrage DPGF & BPU</h4>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  <strong>GPT-5.6 Sol</strong> ou <strong>Claude Opus 5</strong> : modèles de raisonnement à privilégier pour vérifier l'exactitude des métrés et des prix unitaires.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm">🔍</span>
                  <h4 className="font-bold text-slate-900 dark:text-white">Recherche Sémantique (RAG)</h4>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  Vectorisation et découpage des CCTP de 300+ pages pour retrouver et citer immédiatement les exigences exactes du maître d'ouvrage (anti-hallucination).
                </p>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-6">
            <div className="flex flex-wrap items-center justify-between border-b border-slate-100 dark:border-[#243546] pb-4 gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 font-heading">
                  <Key className="w-4 h-4 text-[#1C6091]" />
                  <span>{t('admin.super.keys.section_title')}</span>
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {t('admin.super.keys.section_desc')}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="badge-pill-emerald">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>{t('admin.super.keys.encryption_badge')}</span>
                </span>
              </div>
            </div>

            <form onSubmit={handleSaveMasterKeys} className="space-y-6">
              {/* Platform Default LLM Model Tier Selection */}
              <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <label htmlFor="platform-default-tier-select" className="text-xs font-bold text-slate-900 dark:text-zinc-100 flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-[#1C6091]" />
                    <span>Modèle Master par Défaut de la Plateforme (Moteur LLM Principal)</span>
                  </label>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#1C6091]/10 text-[#1C6091]">
                    Global Plateforme
                  </span>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  Modèle d'IA utilisé pour toute la plateforme (génération du mémoire technique, analyse CCTP et extraction DCE) lorsqu'aucun modèle spécifique n'est assigné à un client ou à une tâche.
                </p>

                {/* Dropdown containing both intelligent BTP tiers AND all direct provider models */}
                <select
                  id="platform-default-tier-select"
                  value={platformDefaultTier}
                  onChange={(e) => setPlatformDefaultTier(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-semibold focus:outline-none focus:ring-1 focus:ring-[#1C6091] cursor-pointer"
                >
                  <optgroup label="Profils & Niveaux Intelligents Recommandés BTP">
                    {LLM_MODEL_TIERS.map((tier) => (
                      <option key={tier.id} value={tier.id}>
                        {tier.display_label}
                      </option>
                    ))}
                  </optgroup>
                  {renderSelectableModelOptions()}
                </select>

                {/* Live Feedback Card */}
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#1C6091]/10 text-[#1C6091] flex items-center justify-center font-bold shrink-0">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-zinc-100">
                          Moteur actif : <span className="font-mono text-[#1C6091]">{activeMasterDetails.modelString}</span>
                        </span>
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          activeMasterDetails.zone === 'UE'
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                            : 'bg-slate-200/70 dark:bg-[#243546] text-muted-foreground'
                        }`}>
                          {activeMasterDetails.zone === 'UE' ? '🇪🇺 Souveraineté UE' : `Zone ${activeMasterDetails.zone}`}
                        </span>
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        Fournisseur : <strong>{activeMasterDetails.providerName}</strong>
                        {activeMasterDetails.pricing && ` • Coût : ${activeMasterDetails.pricing}`}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {activeMasterDetails.hasKey ? (
                      <span className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Clé API configurée</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/25 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                        <span>Clé API requise pour {activeMasterDetails.providerName}</span>
                      </span>
                    )}
                  </div>
                </div>

                {!activeMasterDetails.hasKey && (
                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-700 dark:text-amber-300 text-xs flex items-start gap-2.5">
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div className="min-w-0">
                      <p className="font-bold">Clé API manquante</p>
                      <p className="text-[11px] mt-0.5">
                        Le modèle sélectionné dépend de <strong>{activeMasterDetails.providerName}</strong>, mais aucune clé API n'a été saisie. Renseignez la clé secrète ci-dessous dans la carte du fournisseur correspondant puis cliquez sur « Enregistrer les Clés & le Modèle Master ».
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Fournisseurs d'IA Principaux */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-zinc-100">
                      Fournisseurs d'IA & Clés API
                    </h4>
                    <p className="text-[11px] text-muted-foreground">
                      Configurez vos clés API pour alimenter les moteurs d'extraction, de rédaction et de chiffrage.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddProvider}
                    className="btn-secondary !py-1.5 !px-3 !text-xs cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-[#1C6091]" />
                    <span>+ Ajouter un fournisseur</span>
                  </button>
                </div>

                {/* Live Catalog Auto-Sync Status Card */}
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-[#1C6091]/10 text-[#1C6091] flex items-center justify-center shrink-0">
                      <RefreshCw className={`w-3.5 h-3.5 text-[#1C6091] ${catalogSyncing ? 'animate-spin' : ''}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-zinc-100">
                          Catalogue des Modèles Synchronisé Quotidiennement (Automatique à 4h00)
                        </span>
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                          {llmCatalog?.models ? `${llmCatalog.models.filter(m => m.is_active).length} modèles actifs répertoriés` : 'Synchro active'}
                        </span>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        {llmCatalog?.last_synced_at
                          ? `Dernière mise à jour automatique : ${new Date(llmCatalog.last_synced_at).toLocaleString()} • Tout nouveau modèle de fournisseur est automatiquement disponible avec ses tarifs exacts.`
                          : "Synchronisation automatique active chaque nuit. Les nouveaux modèles d'Anthropic, OpenAI, Mistral et DeepSeek sont automatiquement intégrés avec leurs tarifs officiels."}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleSyncLlmCatalog}
                    disabled={catalogSyncing}
                    className="btn-secondary !py-1.5 !px-3 !text-xs shrink-0 flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className={`w-3 h-3 text-[#1C6091] ${catalogSyncing ? 'animate-spin' : ''}`} />
                    <span>{catalogSyncing ? 'Actualisation en cours...' : 'Actualiser le catalogue maintenant'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {customProviders.map((prov, index) => {
                    const isBuiltin = ['anthropic', 'openai', 'mistral', 'deepseek'].includes(prov.id);
                    const currentMaskedKey = keyStatus?.custom_providers?.find((p: any) => p.id === prov.id)?.api_key;
                    const modelsForThis = providerModelChoices[prov.id];

                    return (
                      <div
                        key={prov.id || index}
                        className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-4 transition-all"
                      >
                        {/* Header Row */}
                        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-[#243546]">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-[#1C6091] text-white flex items-center justify-center font-bold shadow-xs">
                              <Cpu className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-slate-900 dark:text-zinc-100">{prov.name}</span>
                                <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                                  prov.zone === 'UE' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20' : 'bg-slate-100 dark:bg-[#16212D] text-muted-foreground'
                                }`}>
                                  {prov.zone === 'UE' ? '🇪🇺 Souveraineté UE' : `Zone ${prov.zone}`}
                                </span>
                              </div>
                              <p className="text-[10px] text-muted-foreground font-mono mt-0.5">{prov.litellm_id || 'custom'}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            {/* Live Test Status Badge with confirmed model */}
                            {prov.test_status === 'success' && (
                              <span className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25 flex items-center gap-1.5" title={`Modèle confirmé par l'API : ${prov.confirmed_model || prov.litellm_id}`}>
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                                <span>Connecté ({prov.last_latency_ms} ms) • {prov.confirmed_model ? prov.confirmed_model.split('/').pop() : prov.litellm_id}</span>
                              </span>
                            )}
                            {prov.test_status === 'error' && (
                              <span className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/25 flex items-center gap-1.5">
                                <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                                <span>Erreur de connexion</span>
                              </span>
                            )}
                            {(!prov.test_status || prov.test_status === 'untested') && (
                              <span className="text-[10px] text-muted-foreground px-2 py-1 rounded-lg bg-slate-100 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546]">
                                Non testé
                              </span>
                            )}

                            {/* Test Button */}
                            <button
                              type="button"
                              onClick={() => handleTestProvider(index)}
                              disabled={testingProviderId === prov.id}
                              className="btn-secondary !py-1.5 !px-3 !text-xs flex items-center gap-1.5 cursor-pointer"
                            >
                              {testingProviderId === prov.id ? (
                                <>
                                  <Loader2 className="w-3.5 h-3.5 animate-spin text-[#1C6091]" />
                                  <span>Test en cours...</span>
                                </>
                              ) : (
                                <>
                                  <Zap className="w-3.5 h-3.5 text-[#1C6091]" />
                                  <span>Tester la clé</span>
                                </>
                              )}
                            </button>

                            {!isBuiltin && (
                              <button
                                type="button"
                                onClick={() => handleDeleteProvider(index)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
                                title="Supprimer ce fournisseur"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Custom Provider Meta Inputs if not builtin */}
                        {!isBuiltin && (
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pb-1">
                            <div>
                              <label className="block text-[11px] font-semibold text-slate-700 dark:text-zinc-300 mb-1">
                                Nom du Fournisseur
                              </label>
                              <input
                                type="text"
                                value={prov.name || ''}
                                onChange={(e) => handleUpdateProvider(index, 'name', e.target.value)}
                                placeholder="ex: Serveur Local vLLM"
                                className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-medium focus:outline-none focus:ring-1 focus:ring-[#1C6091]"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-semibold text-slate-700 dark:text-zinc-300 mb-1">
                                URL Base API (Optionnel)
                              </label>
                              <input
                                type="text"
                                value={prov.api_base || ''}
                                onChange={(e) => handleUpdateProvider(index, 'api_base', e.target.value)}
                                placeholder="ex: http://localhost:11434/v1"
                                className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-mono focus:outline-none focus:ring-1 focus:ring-[#1C6091]"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-semibold text-slate-700 dark:text-zinc-300 mb-1">
                                Zone d'Hébergement
                              </label>
                              <select
                                value={prov.zone || 'US'}
                                onChange={(e) => handleUpdateProvider(index, 'zone', e.target.value)}
                                className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-medium focus:outline-none focus:ring-1 focus:ring-[#1C6091] cursor-pointer"
                              >
                                <option value="UE">🇪🇺 Union Européenne (RGPD)</option>
                                <option value="US">🇺🇸 États-Unis</option>
                                <option value="Chine">🇨🇳 Asie / Chine</option>
                                <option value="autre">🌍 Autre zone privée</option>
                              </select>
                            </div>
                          </div>
                        )}

                        {/* Configuration Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 dark:text-zinc-300 mb-1">
                              Modèle d'IA par défaut pour ce fournisseur
                            </label>
                            {modelsForThis ? (
                              <div className="space-y-1.5">
                                <select
                                  value={modelsForThis.some(m => m.id === prov.litellm_id) ? prov.litellm_id : '__manual__'}
                                  onChange={(e) => {
                                    if (e.target.value === '__manual__') {
                                      handleUpdateProvider(index, 'litellm_id', '');
                                    } else {
                                      handleUpdateProvider(index, 'litellm_id', e.target.value);
                                    }
                                  }}
                                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-medium focus:outline-none focus:ring-1 focus:ring-[#1C6091] cursor-pointer"
                                >
                                  {modelsForThis.map(m => (
                                    <option key={m.id} value={m.id}>
                                      {m.label} ({m.cost})
                                    </option>
                                  ))}
                                  <option value="__manual__">
                                    ✏️ Saisir un autre identifiant LiteLLM sur-mesure...
                                  </option>
                                </select>
                                {(!modelsForThis.some(m => m.id === prov.litellm_id)) && (
                                  <input
                                    type="text"
                                    value={prov.litellm_id || ''}
                                    onChange={(e) => handleUpdateProvider(index, 'litellm_id', e.target.value)}
                                    placeholder={`ex: ${prov.id}/votre-modele-specifique`}
                                    className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-mono focus:outline-none focus:ring-1 focus:ring-[#1C6091]"
                                  />
                                )}
                              </div>
                            ) : (
                              <input
                                type="text"
                                value={prov.litellm_id || ''}
                                onChange={(e) => handleUpdateProvider(index, 'litellm_id', e.target.value)}
                                placeholder="ex: ollama/mistral ou openai/custom-model"
                                className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-mono focus:outline-none focus:ring-1 focus:ring-[#1C6091]"
                              />
                            )}
                          </div>

                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-[11px] font-semibold text-slate-700 dark:text-zinc-300">
                                Clé API Secrète
                              </label>
                              {currentMaskedKey && (
                                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400">
                                  ✓ Clé enregistrée ({currentMaskedKey})
                                </span>
                              )}
                            </div>
                            <input
                              type="password"
                              value={prov.api_key || ''}
                              onChange={(e) => handleUpdateProvider(index, 'api_key', e.target.value)}
                              placeholder={currentMaskedKey ? "•••••••••••••••• (Laissez vide pour conserver la clé actuelle)" : "sk-..."}
                              className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-mono focus:outline-none focus:ring-1 focus:ring-[#1C6091]"
                            />
                          </div>

                          {/* 02/09 : monthly_budget_usd existe et est reellement applique cote
                              backend (bascule automatique de secours si le budget du mois est
                              atteint, voir model_routing_service.py) depuis le debut, mais
                              n'avait AUCUN champ ici pour le renseigner -- le seul lien reel
                              entre "palier", "clé" et "budget" etait invisible. Ajoute ici,
                              a cote de la clé, plutot que sur un autre onglet. */}
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 dark:text-zinc-300 mb-1">
                              Budget Mensuel (USD, optionnel)
                            </label>
                            <input
                              type="number"
                              min="0"
                              step="1"
                              value={prov.monthly_budget_usd ?? ''}
                              onChange={(e) => handleUpdateProvider(index, 'monthly_budget_usd', e.target.value === '' ? null : Number(e.target.value))}
                              placeholder="ex: 200 (bascule automatique si dépassé)"
                              className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 font-mono focus:outline-none focus:ring-1 focus:ring-[#1C6091]"
                            />
                          </div>
                        </div>

                        {/* Error message callout if test failed */}
                        {prov.test_status === 'error' && prov.last_error_message && (
                          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/25 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                            <div className="min-w-0">
                              <p className="font-bold">Échec du test de clé</p>
                              <p className="font-mono text-[11px] mt-0.5 break-all">{prov.last_error_message}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isSavingKeys}
                  className="btn-primary !py-2.5 !px-6 !text-xs cursor-pointer shadow-sm disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSavingKeys ? 'Enregistrement en cours...' : 'Enregistrer la configuration LLM'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Suivi de la consommation LLM (Tokens & Coûts ce mois-ci) */}
          <div id="llm-consumption" className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-zinc-800/80 pb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-zinc-100 flex items-center gap-2 font-heading">
                  <Activity className="w-4 h-4 text-zinc-400" />
                  <span>{t('admin.super.keys.usage_title')}</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                  {t('admin.super.keys.usage_desc')}
                </p>
              </div>
              <button
                type="button"
                onClick={fetchUsageSummary}
                disabled={usageLoading}
                className="btn-secondary py-1.5 px-3 text-xs shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-zinc-400 ${usageLoading ? 'animate-spin' : ''}`} />
                <span>{usageLoading ? t('admin.super.keys.catalog_btn_syncing') : t('admin.super.keys.usage_btn_refresh')}</span>
              </button>
            </div>

            {usageLoading && !usageSummary ? (
              <div className="p-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-zinc-400" />
              </div>
            ) : !usageSummary || (usageSummary.by_provider && Object.keys(usageSummary.by_provider).length === 0) ? (
              <div className="p-8 text-center text-xs text-slate-500">{t('admin.super.keys.usage_empty')}</div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-slate-50/70 dark:bg-zinc-900/40 border border-slate-200/80 dark:border-zinc-800/80">
                    <p className="text-[10px] font-mono font-medium text-slate-400 dark:text-zinc-500 uppercase">{t('admin.super.keys.usage_total_tokens')}</p>
                    <p className="text-xl font-bold font-mono text-slate-900 dark:text-zinc-100 mt-1">
                      {usageSummary.total_tokens?.toLocaleString('fr-FR') ?? 0}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-slate-50/70 dark:bg-zinc-900/40 border border-slate-200/80 dark:border-zinc-800/80">
                    <p className="text-[10px] font-mono font-medium text-slate-400 dark:text-zinc-500 uppercase">{t('admin.super.keys.usage_estimated_cost')}</p>
                    <p className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                      {(usageSummary.total_cost_usd ?? 0).toFixed(2)} $
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-slate-50/70 dark:bg-zinc-900/40 border border-slate-200/80 dark:border-zinc-800/80">
                    <p className="text-[10px] font-mono font-medium text-slate-400 dark:text-zinc-500 uppercase">{t('admin.super.keys.usage_total_requests')}</p>
                    <p className="text-xl font-bold font-mono text-slate-900 dark:text-zinc-100 mt-1">
                      {usageSummary.total_requests?.toLocaleString('fr-FR') ?? 0}
                    </p>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-left text-[10px] font-mono font-medium uppercase tracking-wider text-slate-400 dark:text-zinc-500 border-b border-slate-100 dark:border-zinc-800/80">
                        <th className="px-3 py-2">{t('admin.super.keys.usage_col_provider')}</th>
                        <th className="px-3 py-2 text-right">{t('admin.super.keys.usage_col_requests')}</th>
                        <th className="px-3 py-2 text-right">{t('admin.super.keys.usage_col_tokens')}</th>
                        <th className="px-3 py-2 text-right">{t('admin.super.keys.usage_col_cost')}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-zinc-800/80">
                      {Object.entries(usageSummary.by_provider || {}).map(([prov, stats]: [string, any]) => (
                        <tr key={prov}>
                          <td className="px-3 py-2.5 font-mono text-[11px] text-slate-900 dark:text-zinc-100 capitalize">{prov}</td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-700 dark:text-zinc-300">
                            {stats.requests?.toLocaleString('fr-FR') ?? 0}
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-700 dark:text-zinc-300">
                            {stats.tokens?.toLocaleString('fr-FR') ?? 0}
                          </td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-600 dark:text-emerald-400 font-semibold">
                            {(stats.cost_usd ?? 0).toFixed(2)} $
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Catalogue de modèles en lecture seule */}
          <div className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-[#243546] pb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 font-heading">
                  <Layers className="w-4 h-4 text-[#1C6091]" />
                  <span>{t('admin.super.keys.catalog_title')}</span>
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5 max-w-xl">
                  {t('admin.super.keys.catalog_desc')}
                </p>
                <p className="text-[10px] text-muted-foreground mt-1">
                  {llmCatalog?.last_synced_at
                    ? t('admin.super.keys.catalog_last_synced', { date: new Date(llmCatalog.last_synced_at).toLocaleString() })
                    : t('admin.super.keys.catalog_never_synced')}
                </p>
              </div>
              <button
                type="button"
                onClick={handleSyncLlmCatalog}
                disabled={catalogSyncing}
                className="btn-secondary !py-1.5 !px-3 !text-xs shrink-0 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-[#1C6091] ${catalogSyncing ? 'animate-spin' : ''}`} />
                <span>{catalogSyncing ? t('admin.super.keys.catalog_btn_syncing') : t('admin.super.keys.catalog_btn_sync')}</span>
              </button>
            </div>

            {catalogLoading ? (
              <div className="p-8 text-center text-xs text-muted-foreground flex items-center justify-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-[#1C6091]" />
              </div>
            ) : !llmCatalog || llmCatalog.models.length === 0 ? (
              <div className="p-8 text-center text-xs text-muted-foreground">{t('admin.super.keys.catalog_empty')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-left text-[10px] font-mono font-bold uppercase tracking-wider text-muted-foreground border-b border-slate-100 dark:border-[#243546]">
                      <th className="px-3 py-2">{t('admin.super.keys.catalog_col_model')}</th>
                      <th className="px-3 py-2">{t('admin.super.keys.catalog_col_provider')}</th>
                      <th className="px-3 py-2 text-right">{t('admin.super.keys.catalog_col_pricing')}</th>
                      <th className="px-3 py-2 text-right">{t('admin.super.keys.catalog_col_context')}</th>
                      <th className="px-3 py-2">{t('admin.super.keys.catalog_col_status')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#243546]">
                    {llmCatalog.models.map((m) => (
                      <tr key={m.id} className={m.is_active ? '' : 'opacity-50'}>
                        <td className="px-3 py-2.5 font-mono text-[11px] text-slate-900 dark:text-zinc-100">{m.display_name || m.external_id}</td>
                        <td className="px-3 py-2.5 text-muted-foreground">{m.provider_slug || '—'}</td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-700 dark:text-zinc-300">
                          {m.pricing_prompt_per_million != null && m.pricing_completion_per_million != null
                            ? `$${m.pricing_prompt_per_million.toFixed(2)} / $${m.pricing_completion_per_million.toFixed(2)}`
                            : '—'}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums text-muted-foreground">
                          {m.context_length ? m.context_length.toLocaleString() : '—'}
                        </td>
                        <td className="px-3 py-2.5">
                          <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full ${m.is_active ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25' : 'bg-slate-100 dark:bg-[#16212D] text-muted-foreground border border-slate-200 dark:border-[#243546]'}`}>
                            {m.is_active ? t('admin.super.keys.catalog_status_active') : t('admin.super.keys.catalog_status_inactive')}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: TASK-BASED LLM ROUTING PER REAL TENANT */}
      {activeTab === 'routing' && (
        <div className="space-y-6">
          {/* Guide d'affectation des modèles par tâche */}
          <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-[#243546] pb-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2 font-heading">
                <Cpu className="w-4 h-4 text-[#1C6091]" />
                <span>Routage Intelligent des Modèles par Entreprise Cliente</span>
              </h3>
              <span className="badge-pill font-medium">
                Personnalisation Multi-Tâches
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1">
                <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#1C6091]"></span>
                  1. Extraction & Synthèse RC
                </p>
                <p className="text-[11px] text-muted-foreground">
                  Extraction ultra-rapide des exigences DCE et décision Go/No-Go. Modèles rapides recommandés (Claude 3.5 Haiku, GPT-4o Mini, Mistral Small).
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1">
                <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                  2. Rédaction Long-Form
                </p>
                <p className="text-[11px] text-muted-foreground">
                  Génération des chapitres détaillés du mémoire technique (30+ pages). Modèles experts recommandés (Claude 3.5 Sonnet, GPT-4o, Mistral Large 2).
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1">
                <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  3. Chiffrage & Prix (DPGF)
                </p>
                <p className="text-[11px] text-muted-foreground">
                  Analyse des déboursés et formules d'indexation BT01. Modèles de raisonnement recommandés (GPT-5.6 Sol, Claude Opus 5, Mistral Large 3).
                </p>
              </div>
            </div>
          </div>

          {/* Search bar for clients */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs">
            <div className="relative flex-1 group">
              <Search className="w-4 h-4 text-slate-400 group-focus-within:text-[#1C6091] absolute left-3.5 top-1/2 -translate-y-1/2 transition-colors" />
              <input
                type="text"
                value={routingSearch}
                onChange={(e) => setRoutingSearch(e.target.value)}
                placeholder="Rechercher une entreprise cliente (nom, SIRET, ID)..."
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 placeholder:text-slate-400 dark:placeholder:text-zinc-500 focus:outline-none focus:border-[#1C6091] transition-all font-medium"
              />
            </div>
            <span className="text-xs text-muted-foreground font-mono self-center shrink-0">
              {filteredRoutingTenants.length} / {tenants.length} client(s)
            </span>
          </div>

          {filteredRoutingTenants.length === 0 ? (
            <div className="p-12 text-center text-xs text-muted-foreground rounded-2xl bg-white dark:bg-[#111A24] border border-dashed border-slate-200 dark:border-[#243546]">
              {tenants.length === 0 ? t('admin.super.routing.empty') : 'Aucune entreprise trouvée pour cette recherche.'}
            </div>
          ) : (
            filteredRoutingTenants.map((tenant) => {
              const routing = tenant.model_routing_config || {};
              const currentGoNoGo = routing.extraction_gonogo?.model || 'anthropic/claude-sonnet-5';
              const currentRedaction = routing.redaction_memoire?.model || tenant.llm_model || 'anthropic/claude-sonnet-5';
              const currentPricing = routing.analyse_prix?.model || 'mistral/mistral-large-3-25-12';

              return (
                <div key={tenant.id} className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-5">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-[#243546] pb-3">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white font-heading">{tenant.name}</h3>
                      <p className="text-[11px] text-muted-foreground font-mono">{t('admin.tenant_detail.id_label', { id: tenant.id })}</p>
                    </div>
                    <span className="badge-pill-emerald">
                      {t('admin.super.routing.active_badge')}
                    </span>
                  </div>

                  {/* Bulk Apply Model to All Tasks */}
                  <div className="flex flex-wrap items-center gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546]">
                    <span className="text-[11px] font-semibold text-slate-700 dark:text-zinc-200">{t('admin.super.routing.bulk_label')}</span>
                    <select
                      value={bulkRoutingSelection[tenant.id] ?? currentRedaction}
                      onChange={(e) => setBulkRoutingSelection(prev => ({ ...prev, [tenant.id]: e.target.value }))}
                      className="px-3 py-2 rounded-lg bg-white dark:bg-[#111A24] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 focus:outline-none focus:border-[#1C6091] cursor-pointer font-medium"
                    >
                      {renderSelectableModelOptions()}
                    </select>
                    <button
                      type="button"
                      onClick={() => handleBulkApplyModelRouting(tenant.id, bulkRoutingSelection[tenant.id] ?? currentRedaction)}
                      className="btn-primary !py-1.5 !px-3 !text-xs cursor-pointer"
                    >
                      {t('admin.super.routing.bulk_btn')}
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                    {/* Task 1: Go/No-Go */}
                    <div className="p-4 rounded-xl bg-slate-50/80 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-2">
                      <label className="block text-xs font-semibold text-slate-800 dark:text-zinc-200">{t('admin.super.routing.task1_label')}</label>
                      <select
                        value={currentGoNoGo}
                        onChange={(e) => handleUpdateModelRouting(tenant.id, 'extraction_gonogo', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-white dark:bg-[#111A24] border border-slate-200 dark:border-[#243546] focus:border-[#1C6091] text-xs text-slate-900 dark:text-zinc-100 focus:outline-none font-medium cursor-pointer"
                      >
                        {renderSelectableModelOptions()}
                      </select>
                      <p className="text-[10px] text-muted-foreground">{t('admin.super.routing.task1_desc')}</p>
                    </div>

                    {/* Task 2: Redaction */}
                    <div className="p-4 rounded-xl bg-slate-50/80 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-2">
                      <label className="block text-xs font-semibold text-slate-800 dark:text-zinc-200">{t('admin.super.routing.task2_label')}</label>
                      <select
                        value={currentRedaction}
                        onChange={(e) => handleUpdateModelRouting(tenant.id, 'redaction_memoire', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] focus:border-[#1C6091] text-xs text-slate-900 dark:text-zinc-100 focus:outline-none font-medium cursor-pointer"
                      >
                        {renderSelectableModelOptions()}
                      </select>
                      <p className="text-[10px] text-muted-foreground">{t('admin.super.routing.task2_desc')}</p>
                    </div>

                    {/* Task 3: Pricing */}
                    <div className="p-4 rounded-xl bg-slate-50/80 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-2">
                      <label className="block text-xs font-semibold text-slate-800 dark:text-zinc-200">{t('admin.super.routing.task3_label')}</label>
                      <select
                        value={currentPricing}
                        onChange={(e) => handleUpdateModelRouting(tenant.id, 'analyse_prix', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] focus:border-[#1C6091] text-xs text-slate-900 dark:text-zinc-100 focus:outline-none font-medium cursor-pointer"
                      >
                        {renderSelectableModelOptions()}
                      </select>
                      <p className="text-[10px] text-muted-foreground">{t('admin.super.routing.task3_desc')}</p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 3: RAG & PGVECTOR SUPERVISION */}
      {activeTab === 'rag_supervision' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-2 shadow-xs">
              <span className="text-[10px] font-mono font-bold text-muted-foreground uppercase">{t('admin.super.rag.status_label')}</span>
              {ragStats.embedding_mode === 'real' ? (
                <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  {t('admin.super.rag.status_online')}
                </p>
              ) : (
                <p className="text-lg font-bold text-[#1C6091] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#1C6091] animate-pulse" />
                  {t('admin.super.rag.status_degraded')}
                </p>
              )}
              <p className="text-[11px] text-muted-foreground font-mono">{ragStats.index_type}</p>
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-2 shadow-xs">
              <span className="text-[10px] font-mono font-bold text-muted-foreground uppercase">{t('admin.super.rag.embedding_model_label')}</span>
              <p className={`text-sm font-bold font-mono ${ragStats.embedding_mode === 'real' ? 'text-slate-900 dark:text-white' : 'text-[#1C6091]'}`}>
                {ragStats.embedding_mode === 'real' ? ragStats.embedding_model : t('admin.super.rag.embedding_model_fallback')}
              </p>
              {ragStats.embedding_mode === 'real' ? (
                <p className="text-[11px] text-muted-foreground font-mono">{t('admin.super.rag.dimensions_suffix', { count: ragStats.dimensions })}</p>
              ) : (
                <p className="text-[11px] text-[#1C6091] leading-tight">{t('admin.super.rag.embedding_key_missing')}</p>
              )}
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-2 shadow-xs">
              <span className="text-[10px] font-mono font-bold text-muted-foreground uppercase">{t('admin.super.rag.dce_chunks_label')}</span>
              <p className="text-xl font-bold text-slate-900 dark:text-white font-mono">{ragStats.total_dce_chunks}</p>
              <p className="text-[11px] text-muted-foreground">{t('admin.super.rag.dce_chunks_note')}</p>
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-2 shadow-xs">
              <span className="text-[10px] font-mono font-bold text-muted-foreground uppercase">{t('admin.super.rag.knowledge_chunks_label')}</span>
              <p className="text-xl font-bold text-slate-900 dark:text-white font-mono">{ragStats.total_knowledge_chunks}</p>
              <p className="text-[11px] text-muted-foreground">{t('admin.super.rag.knowledge_chunks_note')}</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 font-heading">
              <Database className="w-4 h-4 text-[#1C6091]" />
              <span>{t('admin.super.rag.section_title')}</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-700 dark:text-zinc-300">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1.5">
                <p className="font-bold text-slate-900 dark:text-white">{t('admin.super.rag.hnsw_title')}</p>
                <p className="text-muted-foreground leading-relaxed text-[11px]">
                  {t('admin.super.rag.hnsw_desc')}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] space-y-1.5">
                <p className="font-bold text-slate-900 dark:text-white">{t('admin.super.rag.rerank_title')}</p>
                <p className="text-muted-foreground leading-relaxed text-[11px]">
                  {t('admin.super.rag.rerank_desc')}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: ADVANCED SYSTEM PROMPT EDITOR */}
      {activeTab === 'prompts' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-[#243546] pb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 font-heading">
                  <FileCode className="w-4 h-4 text-[#1C6091]" />
                  <span>{t('admin.super.prompt.editor_title')}</span>
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {t('admin.super.prompt.editor_desc')}
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                <select
                  value={selectedTenantForPrompt}
                  onChange={(e) => setSelectedTenantForPrompt(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 focus:outline-none cursor-pointer font-medium"
                >
                  {tenants.map((tenant) => (
                    <option key={tenant.id} value={tenant.id}>{tenant.name}</option>
                  ))}
                </select>

                <button
                  onClick={handleSaveSystemPrompt}
                  disabled={isSavingPrompt}
                  className="btn-primary !py-2 !px-4 !text-xs cursor-pointer shadow-xs disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{isSavingPrompt ? t('admin.super.prompt.btn_saving') : t('admin.super.prompt.btn_save')}</span>
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-zinc-300">
                {t('admin.super.prompt.directives_label')}
              </label>
              <textarea
                rows={12}
                value={currentPrompt}
                onChange={(e) => setCurrentPrompt(e.target.value)}
                placeholder={t('admin.super.prompt.placeholder_prompt')}
                className="w-full p-4 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] focus:border-[#1C6091] text-xs text-slate-800 dark:text-zinc-200 font-mono leading-relaxed focus:outline-none"
              />
              <p className="text-[11px] text-muted-foreground">
                {t('admin.super.prompt.footer_note')}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: REAL TENANTS LIST */}
      {activeTab === 'tenants' && (
        <div className="space-y-4">
          {tenants.length === 0 ? (
            <div className="p-12 rounded-2xl bg-white dark:bg-[#111A24] border border-dashed border-slate-200 dark:border-[#243546] text-center space-y-4">
              <Building2 className="w-10 h-10 text-slate-400 dark:text-zinc-600 mx-auto" />
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white font-heading">{t('admin.super.tenants_tab.empty_title')}</h3>
                <p className="text-xs text-slate-500">{t('admin.super.tenants_tab.empty_desc')}</p>
              </div>
              <button
                onClick={() => setShowCreateModal(true)}
                className="btn-primary !py-2 !px-4 !text-xs cursor-pointer shadow-xs mx-auto"
              >
                <Plus className="w-4 h-4" />
                <span>{t('admin.super.btn_create_tenant')}</span>
              </button>
            </div>
          ) : (
            <div className="bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] rounded-2xl overflow-hidden shadow-xs">
              <div className="divide-y divide-slate-100 dark:divide-[#243546]">
                {tenants.map((tenant) => (
                  <div key={tenant.id} className="p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-50/60 dark:hover:bg-[#16212D]/50 transition-colors">
                    <Link href={`/admin/tenants/${tenant.id}`} className="flex items-center gap-3 group">
                      <div className="w-9 h-9 rounded-xl bg-[#1C6091]/10 text-[#1C6091] font-bold text-xs flex items-center justify-center border border-[#1C6091]/20">
                        {tenant.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-[#1C6091] transition-colors flex items-center gap-1.5 font-heading">
                          <span>{tenant.name}</span>
                          <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-[#1C6091]" />
                        </h3>
                        <p className="text-[11px] text-muted-foreground font-mono">
                          {t('admin.tenants_list.siret_line', { siret: tenant.siret || t('admin.tenants_list.no_siret'), email: tenant.contact_email || t('admin.tenants_list.no_email') })}
                        </p>
                      </div>
                    </Link>

                    <div className="flex items-center gap-3">
                      <Link
                        href={`/admin/tenants/${tenant.id}`}
                        className="btn-secondary !py-1 !px-2.5 !text-[11px]"
                      >
                        {t('admin.super.tenants_tab.btn_manage')}
                      </Link>
                      <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-[#1C6091]/10 text-[#1C6091] border border-[#1C6091]/20 uppercase">
                        {t('admin.tenants_list.plan_badge', { plan: tenant.plan })}
                      </span>
                      <span className="text-xs text-muted-foreground font-mono hidden sm:inline">
                        {t('admin.super.tenants_tab.files_count', { used: tenant.used_this_month || 0, limit: tenant.monthly_limit || 15 })}
                      </span>
                      <button
                        onClick={() => handleDeleteTenant(tenant.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
                        title={t('admin.tenant_detail.delete_title')}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: REVENUE */}
      {activeTab === 'revenue' && (
        <div className="space-y-4">
          {!revenueSummary?.any_payment_processor_verified && (
            <div className="p-4 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] flex items-start gap-2.5 shadow-xs">
              <AlertTriangle className="w-4 h-4 text-[#1C6091] shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed">{t('admin.super.revenue.disclaimer')}</p>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-1.5 shadow-xs">
              <p className="text-xs font-mono font-bold text-muted-foreground uppercase">{t('admin.super.revenue.mrr_label')}</p>
              <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono">
                {revenueLoading && !revenueSummary ? '…' : (revenueSummary?.mrr_estimated_eur ?? 0).toLocaleString('fr-FR')} €
              </p>
              <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                {t('admin.super.revenue.mrr_note', { count: revenueSummary?.billed_active_count ?? 0 })}
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-1.5 shadow-xs">
              <p className="text-xs font-mono font-bold text-muted-foreground uppercase">{t('admin.super.revenue.arr_label')}</p>
              <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono">
                {revenueLoading && !revenueSummary ? '…' : (revenueSummary?.arr_estimated_eur ?? 0).toLocaleString('fr-FR')} €
              </p>
              <p className="text-xs text-muted-foreground">{t('admin.super.revenue.arr_note')}</p>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-1.5 shadow-xs">
              <p className="text-xs font-mono font-bold text-muted-foreground uppercase">{t('admin.super.revenue.storage_label')}</p>
              <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 font-mono">{t('admin.super.revenue.storage_value')}</p>
              <p className="text-xs text-muted-foreground">{t('admin.super.revenue.storage_note')}</p>
            </div>
          </div>

          {revenueSummary && (
            <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs">
              <p className="text-xs font-bold text-slate-900 dark:text-white mb-3 font-heading">{t('admin.super.revenue.breakdown_title')}</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <p className="text-muted-foreground">{t('admin.super.revenue.breakdown_billed')}</p>
                  <p className="font-mono font-bold text-slate-900 dark:text-white">{revenueSummary.billed_active_count}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">{t('admin.super.revenue.breakdown_trial')}</p>
                  <p className="font-mono font-bold text-slate-900 dark:text-white">{revenueSummary.free_trial_count}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">{t('admin.super.revenue.breakdown_custom')}</p>
                  <p className="font-mono font-bold text-slate-900 dark:text-white">{revenueSummary.custom_pricing_count}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">{t('admin.super.revenue.breakdown_none')}</p>
                  <p className="font-mono font-bold text-slate-900 dark:text-white">{revenueSummary.tenants_without_subscription_record}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* CREATE TENANT MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] rounded-2xl p-6 max-w-md w-full shadow-elevated space-y-6 animate-in fade-in zoom-in-95">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white font-heading">{t('admin.super.modal.title')}</h3>
              <p className="text-xs text-muted-foreground mt-1">
                {t('admin.super.modal.desc')}
              </p>
            </div>

            <form onSubmit={handleCreateTenant} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5">{t('admin.super.modal.label_name')}</label>
                <input
                  type="text"
                  required
                  value={newTenantName}
                  onChange={(e) => setNewTenantName(e.target.value)}
                  placeholder={t('admin.super.modal.placeholder_name')}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border text-slate-900 dark:text-zinc-100 text-xs focus:outline-none transition-colors ${
                    isDuplicateName 
                      ? 'border-rose-500 focus:border-rose-500' 
                      : 'border-slate-200 dark:border-[#243546] focus:border-[#1C6091]'
                  }`}
                />
                {isDuplicateName && (
                  <p className="text-[11px] text-rose-500 font-semibold mt-1 flex items-center gap-1">
                    <span>⚠️</span> {t('admin.super.err_duplicate_name')}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5">{t('admin.super.modal.label_siret')}</label>
                <input
                  type="text"
                  value={newTenantSiret}
                  onChange={(e) => setNewTenantSiret(e.target.value)}
                  placeholder={t('admin.super.modal.placeholder_siret')}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#16212D] border text-slate-900 dark:text-zinc-100 text-xs focus:outline-none transition-colors ${
                    isDuplicateSiret 
                      ? 'border-rose-500 focus:border-rose-500' 
                      : 'border-slate-200 dark:border-[#243546] focus:border-[#1C6091]'
                  }`}
                />
                {isDuplicateSiret && (
                  <p className="text-[11px] text-rose-500 font-semibold mt-1 flex items-center gap-1">
                    <span>⚠️</span> {t('admin.super.err_duplicate_siret')}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5">{t('admin.super.modal.label_email')}</label>
                <input
                  type="email"
                  value={newTenantEmail}
                  onChange={(e) => setNewTenantEmail(e.target.value)}
                  placeholder={t('admin.super.modal.placeholder_email')}
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 focus:border-zinc-500 text-slate-900 dark:text-zinc-100 text-xs focus:outline-none"
                />
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5">{t('admin.super.modal.label_plan')}</label>
                  <select
                    value={newTenantPlan}
                    onChange={(e) => setNewTenantPlan(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-xs text-slate-900 dark:text-zinc-100 focus:outline-none cursor-pointer font-medium"
                  >
                    <option value="starter">{t('admin.super.modal.plan_starter')}</option>
                    <option value="pro">{t('admin.super.modal.plan_pro')}</option>
                    <option value="enterprise">{t('admin.super.modal.plan_enterprise')}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5">{t('admin.common.ai_model_override_title')}</label>
                  <select
                    id="new-tenant-tier-select"
                    value={newTenantModelTier}
                    onChange={(e) => setNewTenantModelTier(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-xs text-slate-900 dark:text-zinc-100 focus:outline-none cursor-pointer font-medium"
                  >
                    <option value="inherit">{t('admin.common.inherit_option')}</option>
                    {LLM_MODEL_TIERS.map((tier) => (
                      <option key={tier.id} value={tier.id}>
                        {tier.display_label}
                      </option>
                    ))}
                  </select>
                  <p className="text-[10px] text-slate-400 dark:text-zinc-500 mt-1">
                    {t('admin.super.modal.hint_inherit')}
                  </p>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn-secondary flex-1 py-2 text-xs"
                >
                  {t('admin.common.btn_cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isCreating || isDuplicateName || isDuplicateSiret || !newTenantName.trim()}
                  className="btn-primary flex-1 py-2 text-xs disabled:opacity-50"
                >
                  {isCreating ? t('admin.super.modal.btn_creating') : t('admin.super.modal.btn_create_submit')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default function SuperAdminPage() {
  return (
    <React.Suspense
      fallback={
        <div className="p-20 text-center space-y-3">
          <Loader2 className="w-8 h-8 text-[#1C6091] animate-spin mx-auto" />
          <p className="text-xs text-slate-600 dark:text-slate-400">Chargement de l'administration...</p>
        </div>
      }
    >
      <SuperAdminPageContent />
    </React.Suspense>
  );
}
