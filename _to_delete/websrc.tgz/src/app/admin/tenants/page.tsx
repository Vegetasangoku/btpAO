'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Building2,
  Plus,
  ShieldCheck,
  Loader2,
  Trash2,
  ChevronRight,
  Search,
  Users,
  Activity,
  Layers,
  Sparkles,
  ExternalLink,
  Sliders,
} from 'lucide-react';
import { api } from '@/lib/api';
import { Tenant } from '@/lib/types';
import { useTranslation } from '@/components/i18n-provider';
import { DismissibleNotice } from '@/components/ui/dismissible-notice';

export default function AdminTenantsListPage() {
  const { t } = useTranslation();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [planFilter, setPlanFilter] = useState<string>('all');

  async function loadTenants() {
    setLoading(true);
    setLoadError(null);
    try {
      const data = await api.getTenants();
      setTenants(data || []);
    } catch (err: any) {
      // Ne jamais afficher silencieusement "aucune entreprise" quand c'est en
      // réalité l'appel réseau qui a échoué (base de données lente/injoignable) :
      // on distingue explicitement un vrai vide d'un échec de chargement.
      console.error('Erreur chargement tenants:', err);
      setTenants([]);
      setLoadError(String(err?.message || err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadTenants();
  }, []);

  async function handleQuickDelete(e: React.MouseEvent, tenant: Tenant) {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm(t('admin.tenants_list.confirm_delete', { name: tenant.name }))) return;
    try {
      await api.deleteTenant(tenant.id);
      setTenants((prev) => prev.filter((t) => t.id !== tenant.id));
    } catch (err: any) {
      alert(t('admin.tenants_list.delete_error', { error: String(err?.message || err) }));
    }
  }

  const filteredTenants = tenants.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.siret && t.siret.includes(searchTerm)) ||
      (t.contact_email && t.contact_email.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesPlan = planFilter === 'all' || t.plan === planFilter;
    return matchesSearch && matchesPlan;
  });

  const totalDCE = tenants.reduce((acc, t) => acc + (t.used_this_month || 0), 0);

  return (
    <div className="space-y-8 pb-20 max-w-6xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#1C6091]/10 text-[#1C6091] border border-[#1C6091]/20">
              {t('admin.tenants_list.badge')}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight font-heading">
            {t('admin.tenants_list.heading')}
          </h1>
          <p className="text-xs text-slate-600 dark:text-zinc-400 mt-0.5 font-medium">
            {t('admin.tenants_list.subtitle', { count: String(tenants.length) })}
          </p>
        </div>

        <Link
          href="/admin?create=1"
          className="btn-primary !py-2 !px-4 !text-xs"
        >
          <Plus className="w-4 h-4" />
          <span>{t('admin.tenants_list.btn_create')}</span>
        </Link>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-1.5 shadow-xs transition-all">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-bold font-heading">
            <span>{t('admin.tenants_list.kpi_accounts')}</span>
            <Building2 className="w-4 h-4 text-[#1C6091]" />
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono">{tenants.length}</p>
          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">{t('admin.tenants_list.kpi_accounts_note')}</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-1.5 shadow-xs transition-all">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-bold font-heading">
            <span>{t('admin.tenants_list.kpi_volume')}</span>
            <Activity className="w-4 h-4 text-[#1C6091]" />
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono">{t('admin.tenants_list.kpi_volume_value', { count: String(totalDCE) })}</p>
          <p className="text-[11px] text-muted-foreground">{t('admin.tenants_list.kpi_volume_note')}</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] space-y-1.5 shadow-xs transition-all">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-bold font-heading">
            <span>{t('admin.tenants_list.kpi_routing')}</span>
            <Sparkles className="w-4 h-4 text-[#1C6091]" />
          </div>
          <p className="text-sm font-bold text-slate-900 dark:text-white font-heading mt-1">{t('admin.tenants_list.kpi_routing_value')}</p>
          <p className="text-[11px] text-muted-foreground">{t('admin.tenants_list.kpi_routing_note')}</p>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] shadow-xs">
        <div className="relative flex-1 group">
          <Search className="w-4 h-4 text-slate-400 group-focus-within:text-[#1C6091] absolute left-3.5 top-1/2 -translate-y-1/2 transition-colors" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t('admin.tenants_list.search_placeholder')}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 placeholder:text-slate-400 focus:border-[#1C6091] focus:outline-none transition-all font-medium"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-500 dark:text-zinc-400 whitespace-nowrap pl-1 font-semibold">{t('admin.tenants_list.plan_label')}</span>
          <select
            value={planFilter}
            onChange={(e) => setPlanFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200 dark:border-[#243546] text-xs text-slate-900 dark:text-zinc-100 focus:border-[#1C6091] focus:outline-none cursor-pointer font-medium"
          >
            <option value="all">{t('admin.tenants_list.plan_all', { count: String(tenants.length) })}</option>
            <option value="enterprise">Enterprise</option>
            <option value="pro">Pro</option>
            <option value="starter">Starter</option>
          </select>
        </div>
      </div>

      {loadError && (
        <div className="space-y-2">
          <DismissibleNotice
            variant="error"
            message={t('admin.tenants_list.load_error_title')}
            detail={loadError}
            onDismiss={() => setLoadError(null)}
          />
          <button
            type="button"
            onClick={loadTenants}
            className="text-xs font-bold text-[#1C6091] hover:underline cursor-pointer"
          >
            {t('admin.tenants_list.load_error_retry')}
          </button>
        </div>
      )}

      {/* Tenants Cards Grid */}
      {loading ? (
        <div className="p-20 text-center space-y-3">
          <Loader2 className="w-8 h-8 text-[#1C6091] animate-spin mx-auto" />
          <p className="text-xs text-slate-500 dark:text-zinc-400 font-medium">{t('admin.tenants_list.loading')}</p>
        </div>
      ) : filteredTenants.length === 0 ? (
        <div className="p-16 rounded-2xl bg-white dark:bg-[#111A24] border border-dashed border-slate-200 dark:border-[#243546] text-center space-y-4">
          <Building2 className="w-10 h-10 text-slate-400 dark:text-zinc-600 mx-auto" />
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white font-heading">{t('admin.tenants_list.empty_title')}</h3>
            <p className="text-xs text-slate-500">{t('admin.tenants_list.empty_body')}</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-2.5">
          {filteredTenants.map((tenant) => (
            <div
              key={tenant.id}
              className="p-4 rounded-2xl bg-white dark:bg-[#111A24] border border-slate-200/80 dark:border-[#243546] hover:border-slate-300 dark:hover:border-[#1C6091]/50 flex items-center justify-between transition-all group shadow-xs"
            >
              <Link
                href={`/admin/tenants/${tenant.id}`}
                className="flex items-center gap-3.5 flex-1 min-w-0"
              >
                <div className="w-10 h-10 rounded-xl bg-[#1C6091] text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-xs">
                  {tenant.name.substring(0, 2).toUpperCase()}
                </div>
                <div className="truncate space-y-0.5">
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-[#1C6091] transition-colors truncate font-heading">
                      {tenant.name}
                    </h3>
                    <span className="badge-pill text-[9px] px-1.5 py-0.2 font-mono">
                      {tenant.country_code || 'FR'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 dark:text-zinc-500 font-mono truncate">
                    {t('admin.tenants_list.siret_line', { siret: tenant.siret || t('admin.tenants_list.no_siret'), email: tenant.contact_email || t('admin.tenants_list.no_email') })}
                  </p>
                </div>
              </Link>

              <div className="flex items-center gap-3 shrink-0 ml-3">
                <span className={`badge-pill text-[9px] font-mono uppercase ${
                  tenant.plan === 'enterprise'
                    ? 'badge-pill-primary'
                    : ''
                }`}>
                  <span className={`h-1.5 w-1.5 rounded-full ${tenant.plan === 'enterprise' ? 'bg-white' : 'bg-slate-400'}`}></span>
                  {tenant.plan || 'Starter'}
                </span>

                <button
                  type="button"
                  onClick={(e) => handleQuickDelete(e, tenant)}
                  title={t('admin.tenants_list.delete_title')}
                  className="p-1.5 rounded-md text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>

                <Link
                  href={`/admin/tenants/${tenant.id}`}
                  className="p-1.5 rounded-md text-slate-400 group-hover:text-[#1C6091] group-hover:translate-x-0.5 transition-all cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
