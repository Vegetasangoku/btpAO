'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  HardHat,
  Mail,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Building,
  ArrowLeft,
  KeyRound,
} from 'lucide-react';
import { api } from '@/lib/api';
import { supabase } from '@/lib/supabase/client';
import { useTranslation } from '@/components/i18n-provider';

export default function ForgotPasswordPage() {
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) {
      setErrorMsg(t('auth.forgot.error_email_required'));
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    try {
      // 1. Dispatch real email via Supabase Auth mailer
      try {
        await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/reset-password`,
        });
      } catch (sbErr: any) {
        console.warn('Supabase resetPasswordForEmail warning:', sbErr);
      }

      // 2. Also register in backend audit & token system
      try {
        await api.requestPasswordReset(email.trim());
      } catch (apiErr: any) {
        console.warn('Backend requestPasswordReset notice:', apiErr);
      }

      setSuccess(true);
    } catch (err: any) {
      setErrorMsg(err?.message || t('auth.forgot.error_generic'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#EAF1F5] dark:bg-[#0A121A] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden transition-colors duration-200 font-sans">
      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10 text-center space-y-3">
        {/* Brand Icon */}
        <div className="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-[#1C6091] text-white shadow-sm mb-1">
          <HardHat className="w-5 h-5" />
        </div>

        {/* Top Badge */}
        <div>
          <span className="badge-pill text-[10px]">
            <Building className="w-3 h-3 text-[#1C6091]" />
            {t('auth.forgot.badge')}
          </span>
        </div>

        <h1 className="text-xl sm:text-2xl font-extrabold text-foreground tracking-tight font-heading">
          {t('auth.forgot.heading_prefix')} <span className="text-[#1C6091]">{t('auth.forgot.heading_highlight')}</span>
        </h1>
        <p className="text-[13px] text-muted-foreground max-w-sm mx-auto">
          {t('auth.forgot.subtitle')}
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md relative z-10 px-4">
        <div className="card-elevated p-7 sm:p-8 space-y-5 rounded-2xl animate-fade-in-up">
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-500/8 border border-rose-500/20 text-rose-700 dark:text-rose-400 text-[13px] flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="font-medium">{errorMsg}</span>
            </div>
          )}

          {success ? (
            <div className="space-y-4 text-center py-2">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 flex items-center justify-center mx-auto shadow-xs">
                <CheckCircle2 className="w-6 h-6" />
              </div>

              <div className="space-y-1.5">
                <h2 className="text-sm font-bold text-slate-900 dark:text-white font-heading">{t('auth.forgot.success_title')}</h2>
                <p className="text-xs text-slate-600 dark:text-zinc-400 leading-relaxed">
                  {t('auth.forgot.success_body', { email })}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#16212D] border border-slate-200/80 dark:border-[#243546] text-[11px] text-slate-600 dark:text-zinc-400 text-left space-y-1 font-mono">
                <p className="font-semibold text-slate-800 dark:text-zinc-200">{t('auth.forgot.validity_note_label')}</p>
                <p>{t('auth.forgot.validity_note_body')}</p>
              </div>

              <Link
                href="/login"
                className="inline-flex items-center justify-center gap-1.5 w-full py-2.5 px-4 rounded-xl bg-[#1C6091] hover:bg-[#154A73] text-white font-bold text-xs transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{t('auth.forgot.back_to_login')}</span>
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-mono font-bold uppercase tracking-wider text-slate-700 dark:text-zinc-300 mb-1.5">
                  {t('auth.forgot.label_email')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-zinc-500">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="directeur@eiffabtp.fr"
                    className="input-field-with-icon"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full !py-3 cursor-pointer"
              >
                {loading ? (
                  <span>{t('auth.forgot.sending')}</span>
                ) : (
                  <>
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>{t('auth.forgot.btn_submit')}</span>
                  </>
                )}
              </button>

              <div className="pt-2 border-t border-slate-100 dark:border-[#243546] flex items-center justify-between text-xs text-slate-500 dark:text-zinc-400">
                <Link
                  href="/login"
                  className="inline-flex items-center gap-1 text-[#1C6091] hover:underline transition-colors text-[11px] cursor-pointer"
                >
                  <ArrowLeft className="w-3 h-3" />
                  <span>{t('auth.forgot.back_to_login')}</span>
                </Link>

                <Link href="/register" className="text-slate-800 dark:text-zinc-200 hover:text-[#1C6091] font-semibold text-[11px] cursor-pointer">
                  {t('auth.forgot.create_account')}
                </Link>
              </div>
            </form>
          )}
        </div>

        {/* Footer Security Badge */}
        <div className="mt-6 text-center flex items-center justify-center gap-2 text-[12px] text-muted-foreground">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>{t('auth.forgot.footer_rgpd')}</span>
        </div>
      </div>
    </div>
  );
}
