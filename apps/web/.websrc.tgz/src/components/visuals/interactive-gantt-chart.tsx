'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { BarChart3, RefreshCw, Calendar, AlertTriangle, Plus, Trash2, Flag, Sparkles } from 'lucide-react';
// @ts-ignore -- vendored, untyped-by-upstream JS bundle; see index.d.ts for the hand-written surface we rely on.
import Gantt from '@/vendor/frappe-gantt/frappe-gantt.es.js';
import '@/vendor/frappe-gantt/frappe-gantt.css';
import '@/vendor/frappe-gantt/frappe-gantt-overrides.css';
import { api } from '@/lib/api';
import { GanttTask } from '@/lib/types';
import { useTranslation } from '@/components/i18n-provider';

interface InteractiveGanttChartProps {
  projectId: string;
  projectTitle?: string;
}

/** Adds `days` to an ISO "YYYY-MM-DD" string via a UTC-noon pivot (sidesteps any DST
 *  edge case entirely) -- used for pure date-only arithmetic that never touches a
 *  timezone-sensitive `Date` object constructed by the browser. */
function addDaysIso(iso: string, days: number): string {
  const [y, m, d] = iso.split('-').map(Number);
  const t = Date.UTC(y, (m || 1) - 1, d || 1, 12) + days * 86400000;
  const dt = new Date(t);
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}-${String(dt.getUTCDate()).padStart(2, '0')}`;
}

/** Reads a `Date` object's LOCAL calendar fields (never `.toISOString()`, which
 *  converts to UTC and can silently shift the date by a day depending on the
 *  viewer's timezone offset) -- used to convert the Date objects frappe-gantt hands
 *  back from on_date_change into the "YYYY-MM-DD" strings the API expects. */
function localIso(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function InteractiveGanttChart({ projectId, projectTitle = 'Projet BTP' }: InteractiveGanttChartProps) {
  const { t, language } = useTranslation();
  const [tasks, setTasks] = useState<GanttTask[]>([]);
  const [loadState, setLoadState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [authExpired, setAuthExpired] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportInfo, setExportInfo] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'Day' | 'Week' | 'Month'>('Week');
  const [nameEdits, setNameEdits] = useState<Record<string, string>>({});
  const containerRef = useRef<HTMLDivElement | null>(null);
  const ganttRef = useRef<any>(null);

  const reload = useCallback(async () => {
    try {
      const res = await api.listGanttTasks(projectId);
      setTasks(res);
      setLoadState('ready');
    } catch (err: any) {
      console.error('Failed to load Gantt tasks', err);
      setAuthExpired(err?.status === 401);
      setLoadState('error');
    }
  }, [projectId]);

  useEffect(() => {
    let cancelled = false;
    setLoadState('loading');
    ganttRef.current = null;
    api.listGanttTasks(projectId)
      .then((res) => {
        if (cancelled) return;
        setTasks(res);
        setLoadState('ready');
      })
      .catch((err: any) => {
        console.error('Failed to load Gantt tasks', err);
        if (!cancelled) {
          setAuthExpired(err?.status === 401);
          setLoadState('error');
        }
      });
    return () => {
      cancelled = true;
    };
  }, [projectId]);

  const persistDateChange = useCallback(async (taskId: string, start: Date, end: Date) => {
    try {
      await api.updateGanttTask(projectId, taskId, { start_date: localIso(start), end_date: localIso(end) });
      await reload();
    } catch (err) {
      console.error('Failed to persist Gantt date change', err);
      await reload(); // resync the chart with the server's authoritative state either way
    }
  }, [projectId, reload]);

  const persistProgressChange = useCallback(async (taskId: string, progress: number) => {
    try {
      await api.updateGanttTask(projectId, taskId, { progress: Math.round(progress) });
      await reload();
    } catch (err) {
      console.error('Failed to persist Gantt progress change', err);
      await reload();
    }
  }, [projectId, reload]);

  useEffect(() => {
    if (loadState !== 'ready') return;

    if (tasks.length === 0) {
      // Container isn't rendered in the empty state (see JSX below) -- any prior
      // instance is now bound to a detached node, so drop it. The next time tasks
      // becomes non-empty a fresh instance gets created against the freshly-mounted div.
      ganttRef.current = null;
      return;
    }
    if (!containerRef.current) return;

    const frappeTasks = tasks.map((task) => ({
      id: task.id,
      name: task.is_milestone ? `◆ ${task.name}${task.milestone_label ? ' — ' + task.milestone_label : ''}` : task.name,
      start: task.start_date,
      end: task.end_date,
      progress: task.progress,
      dependencies: task.depends_on.join(','),
      custom_class: task.is_critical ? 'gantt-critical' : task.is_milestone ? 'gantt-milestone' : '',
    }));

    if (!ganttRef.current) {
      ganttRef.current = new Gantt(containerRef.current, frappeTasks, {
        view_mode: viewMode,
        language,
        readonly: false,
        move_dependencies: true,
        popup_on: 'click',
        on_date_change: (task: any, start: Date, end: Date) => {
          persistDateChange(task.id, start, end);
        },
        on_progress_change: (task: any, progress: number) => {
          persistProgressChange(task.id, progress);
        },
      });
    } else {
      ganttRef.current.refresh(frappeTasks);
    }
    // Deliberately excludes persistDateChange/persistProgressChange/viewMode: the
    // handlers are captured once at instantiation and stay valid (they always fetch
    // fresh state via reload() rather than closing over stale `tasks`); viewMode has
    // its own effect below via change_view_mode so it doesn't need to force a rebuild.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tasks, loadState]);

  useEffect(() => {
    if (ganttRef.current && tasks.length > 0) {
      ganttRef.current.change_view_mode(viewMode);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewMode]);

  const handleAddTask = async () => {
    const last = tasks.length > 0 ? [...tasks].sort((a, b) => a.end_date.localeCompare(b.end_date)).pop() : undefined;
    const start = last ? last.end_date : new Date().toISOString().slice(0, 10);
    try {
      await api.createGanttTask(projectId, {
        name: 'Nouvelle tâche',
        start_date: start,
        end_date: addDaysIso(start, 7),
        progress: 0,
        is_milestone: false,
        depends_on: last ? [last.id] : [],
      });
      await reload();
    } catch (err) {
      console.error('Failed to add Gantt task', err);
    }
  };

  const handleDelete = async (taskId: string) => {
    try {
      await api.deleteGanttTask(projectId, taskId);
      await reload();
    } catch (err) {
      console.error('Failed to delete Gantt task', err);
    }
  };

  const handleRenameCommit = async (task: GanttTask, newName: string) => {
    setNameEdits((prev) => {
      const next = { ...prev };
      delete next[task.id];
      return next;
    });
    const trimmed = newName.trim();
    if (!trimmed || trimmed === task.name) return;
    try {
      await api.updateGanttTask(projectId, task.id, { name: trimmed });
      await reload();
    } catch (err) {
      console.error('Failed to rename Gantt task', err);
    }
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const res = await api.generateGantt(projectId, projectTitle, []);
      const criticalCount = (res as any).critical_task_count;
      setExportInfo(
        t('visuals.gantt_interactive.export_weeks', { weeks: res.total_weeks }) +
        (typeof criticalCount === 'number' ? t('visuals.gantt_interactive.export_critical', { count: criticalCount }) : '') +
        t('visuals.gantt_interactive.export_delivery', { date: res.completion_date })
      );
    } catch (err) {
      console.error('Failed to export Gantt', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="card-modern p-5 space-y-4 font-sans">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-line">
        <div>
          <h3 className="text-[13px] font-bold text-foreground flex items-center gap-2 font-heading">
            <BarChart3 className="w-4 h-4 text-hl" />
            {t('visuals.gantt_interactive.title')}
          </h3>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            {t('visuals.gantt_interactive.subtitle')}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="tab-group !p-0.5">
            {(['Day', 'Week', 'Month'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setViewMode(m)}
                className={`px-2.5 py-1 text-[11px] font-mono font-medium transition-all duration-200 cursor-pointer rounded-md ${
                  viewMode === m
                    ? 'bg-hl text-hl-contrast font-bold shadow-xs'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {m === 'Day' ? t('visuals.gantt_interactive.view_day') : m === 'Week' ? t('visuals.gantt_interactive.view_week') : t('visuals.gantt_interactive.view_month')}
              </button>
            ))}
          </div>
          <button
            onClick={handleAddTask}
            className="btn-secondary !py-1.5 !px-2.5 !text-[11px] cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            {t('visuals.gantt_interactive.add_task_btn')}
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting || tasks.length === 0}
            className="btn-primary !py-1.5 !px-2.5 !text-[11px] cursor-pointer"
          >
            <RefreshCw className={`w-3 h-3 ${isExporting ? 'animate-spin' : ''}`} />
            {isExporting ? t('visuals.gantt_interactive.exporting') : t('visuals.gantt_interactive.export_btn')}
          </button>
        </div>
      </div>

      {exportInfo && (
        <div className="p-2.5 rounded-xl bg-positive/8 border border-positive/20 text-positive text-[12px] flex items-center gap-2 font-mono">
          <Sparkles className="w-3.5 h-3.5 shrink-0 text-positive" />
          <span>{t('visuals.gantt_interactive.export_success_prefix')} {exportInfo}</span>
        </div>
      )}

      <div className="relative rounded-xl border border-line overflow-x-auto card-inset min-h-[280px]">
        {loadState === 'loading' ? (
          <div className="flex flex-col items-center justify-center gap-2 text-muted-foreground text-xs py-14 font-mono">
            <RefreshCw className="w-5 h-5 animate-spin text-hl" />
            {t('visuals.gantt_interactive.loading')}
          </div>
        ) : loadState === 'error' ? (
          <div className="flex flex-col items-center justify-center gap-2 text-danger text-xs text-center px-6 py-14">
            <AlertTriangle className="w-6 h-6" />
            {t(authExpired ? 'visuals.gantt_interactive.error_title_auth' : 'visuals.gantt_interactive.error_title')}
          </div>
        ) : tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-2 text-muted-foreground text-xs text-center px-6 py-14">
            <Calendar className="w-7 h-7 opacity-40" />
            <p>{t('visuals.gantt_interactive.empty_title')}</p>
            <button onClick={handleAddTask} className="text-hl font-semibold underline cursor-pointer">
              {t('visuals.gantt_interactive.empty_add_btn')}
            </button>
          </div>
        ) : (
          <div ref={containerRef} className="gantt-target p-2" />
        )}
      </div>

      {tasks.length > 0 && (
        <div className="space-y-1.5">
          <div className="text-[10px] font-mono font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
            <Flag className="w-3 h-3 text-hl" /> {t('visuals.gantt_interactive.tasks_count', { count: tasks.length })}
          </div>
          <div className="max-h-48 overflow-y-auto space-y-1 pr-1 divide-y divide-transparent">
            {tasks.map((task) => (
              <div
                key={task.id}
                className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs border transition-colors ${
                  task.is_critical
                    ? 'border-danger/25 bg-danger/50 dark:bg-danger/20'
                    : 'border-line bg-card'
                }`}
              >
                {task.is_critical && (
                  <span className="w-1.5 h-1.5 rounded-full bg-danger shrink-0" title={t('visuals.gantt_interactive.critical_path_title')} />
                )}
                <input
                  value={nameEdits[task.id] ?? task.name}
                  onChange={(e) => setNameEdits((prev) => ({ ...prev, [task.id]: e.target.value }))}
                  onBlur={(e) => handleRenameCommit(task, e.target.value)}
                  className="flex-1 min-w-0 bg-transparent text-slate-800 dark:text-zinc-200 font-medium focus:outline-none focus:ring-1 focus:ring-hl rounded px-1 text-xs"
                />
                <span className="text-[10px] font-mono text-muted-foreground shrink-0 tabular-nums">
                  {task.start_date} → {task.end_date}
                </span>
                <span className="text-[10px] font-mono text-muted-foreground shrink-0 tabular-nums w-8 text-right font-semibold">{task.progress}%</span>
                <button
                  onClick={() => handleDelete(task.id)}
                  className="text-slate-300 dark:text-zinc-600 hover:text-danger dark:hover:text-danger shrink-0 cursor-pointer p-0.5"
                  title={t('visuals.gantt_interactive.delete_task_title')}
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-center justify-between text-[11px] font-mono text-muted-foreground pt-2 border-t border-line">
        <span>{t('visuals.gantt_interactive.footer_text')}</span>
        <span className="text-hl font-semibold">{t('visuals.section3_badge')}</span>
      </div>
    </div>
  );
}
