'use client';

import React, { useEffect, useRef, useState } from 'react';
import { Users, RefreshCw, AlertTriangle } from 'lucide-react';
import { api, fetchAuthenticatedBlobUrl } from '@/lib/api';
import { useTranslation } from '@/components/i18n-provider';

interface OrganigrammePreviewProps {
  projectId: string;
  projectTitle?: string;
  initialImageUrl?: string;
}

export function OrganigrammePreview({ projectId, projectTitle = 'Projet BTP', initialImageUrl }: OrganigrammePreviewProps) {
  const { t } = useTranslation();
  const apiBase = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/$/, '');
  const [rawPath, setRawPath] = useState<string>(
    // Pas de tenant hardcodé ici : "self/" est résolu côté backend depuis le token
    // d'auth réel de l'utilisateur courant (voir get_visual_file) -- avant ce correctif,
    // ce chemin pointait TOUJOURS vers le tenant de démo 11111111-..., donc pour tout
    // vrai client le backend rejetait la requête (tenant différent) et son fallback
    // renvoyait alors une fausse image de planning Gantt affichée comme "organigramme".
    initialImageUrl || `${apiBase}/api/visuals/file/self/visuals/${projectId}/organigramme_chantier.png`
  );
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [loadState, setLoadState] = useState<'loading' | 'ready' | 'missing' | 'error'>('loading');
  const [authExpired, setAuthExpired] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const objectUrlRef = useRef<string | null>(null);

  async function loadImage(path: string) {
    setLoadState('loading');
    setAuthExpired(false);
    try {
      const url = await fetchAuthenticatedBlobUrl(path);
      if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
      objectUrlRef.current = url;
      setBlobUrl(url);
      setLoadState('ready');
    } catch (err: any) {
      if (err?.status === 404 || String(err?.message || '').includes('404')) {
        setLoadState('missing');
      } else {
        console.error('Failed to load organigramme image', err);
        setAuthExpired(err?.status === 401);
        setLoadState('error');
      }
    }
  }

  useEffect(() => {
    loadImage(rawPath);
    return () => {
      if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rawPath]);

  const handleRegenerate = async () => {
    setIsGenerating(true);
    try {
      const res = await api.generateOrganigramme(projectId, projectTitle, []);
      setRawPath(`${apiBase}/api/visuals/file/${res.s3_key}?t=${Date.now()}`);
    } catch (err) {
      console.error('Failed to generate organigramme', err);
      setLoadState('error');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="card-modern p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200/60 dark:border-zinc-800/40">
        <div>
          <h3 className="text-[13px] font-bold text-foreground flex items-center gap-2 font-heading">
            <Users className="w-4 h-4 text-hl" />
            {t('visuals.organigramme.title')}
          </h3>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            {t('visuals.organigramme.subtitle')}
          </p>
        </div>

        <button
          onClick={handleRegenerate}
          disabled={isGenerating}
          className="btn-primary !py-1.5 !px-3 !text-[11px]"
        >
          <RefreshCw className={`w-3 h-3 ${isGenerating ? 'animate-spin' : ''}`} />
          <span>{isGenerating ? t('visuals.organigramme.generating') : t('visuals.organigramme.regenerate_btn')}</span>
        </button>
      </div>

      {/* Image Preview */}
      <div className="relative rounded-xl border border-slate-200/60 dark:border-zinc-800/50 overflow-hidden card-inset flex items-center justify-center p-2 min-h-[320px]">
        {loadState === 'ready' && blobUrl ? (
          <img
            src={blobUrl}
            alt={t('visuals.organigramme.alt_text')}
            className="w-full h-auto rounded-lg shadow-md object-contain max-h-[500px]"
          />
        ) : loadState === 'loading' || isGenerating ? (
          <div className="flex flex-col items-center gap-2 text-slate-500 text-xs">
            <RefreshCw className="w-6 h-6 animate-spin" />
            {t('visuals.organigramme.loading')}
          </div>
        ) : loadState === 'missing' ? (
          <div className="flex flex-col items-center gap-2 text-slate-500 text-xs text-center px-6">
            <Users className="w-8 h-8 text-slate-400 dark:text-slate-600" />
            {t('visuals.organigramme.empty_title')}
            <span>{t('visuals.organigramme.empty_hint')}</span>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 text-danger text-xs text-center px-6">
            <AlertTriangle className="w-8 h-8" />
            {t(authExpired ? 'visuals.organigramme.error_title_auth' : 'visuals.organigramme.error_title')}
            <span>{t('visuals.organigramme.error_hint')}</span>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-900">
        <span>{t('visuals.organigramme.footer_text')}</span>
        <span className="text-positive font-medium">{t('visuals.organigramme.footer_badge')}</span>
      </div>
    </div>
  );
}
