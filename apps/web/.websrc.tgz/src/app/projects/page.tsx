import { redirect } from 'next/navigation';

export default function ProjectsRedirect() {
  redirect('/dashboard/projects');
}
